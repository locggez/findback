using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.Security;

namespace FindBack.Web.Controllers
{
    /// <summary>Lop cha cua moi Controller: mo ket noi DB, lay user hien tai, chan tai khoan bi khoa.</summary>
    public abstract class BaseController : Controller
    {
        protected readonly FindBackEntities Db = new FindBackEntities();

        // Dang nhap: ticket.Name = UserId (xem AccountController.SignIn + Global.asax.cs)
        protected int CurrentUserId
        {
            get
            {
                int id;
                return (User != null && User.Identity.IsAuthenticated && int.TryParse(User.Identity.Name, out id)) ? id : 0;
            }
        }

        protected int? CurrentUserIdOrNull
        {
            get { return Request.IsAuthenticated ? (int?)CurrentUserId : null; }
        }

        protected bool IsAdmin { get { return User != null && User.IsInRole("Admin"); } }

        protected ActionResult Forbidden()
        {
            return new HttpStatusCodeResult(HttpStatusCode.Forbidden, "Bạn không có quyền thực hiện thao tác này.");
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Neu tai khoan bi admin khoa (hoac bi xoa) -> dang xuat ngay
            if (Request.IsAuthenticated)
            {
                int id = CurrentUserId;
                bool active = Db.Users.Any(u => u.UserId == id && u.IsActive);
                if (!active)
                {
                    FormsAuthentication.SignOut();
                    filterContext.Result = new RedirectResult("~/Account/Login");
                    return;
                }
            }
            base.OnActionExecuting(filterContext);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) Db.Dispose();
            base.Dispose(disposing);
        }
    }
}
