using System.Web.Mvc;
using FindBack.Web.Services;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Controllers
{
    public class PostsController : BaseController
    {
        private readonly PostService _posts;
        private readonly MatchService _matches;

        public PostsController()
        {
            _posts = new PostService(Db);
            _matches = new MatchService(Db);
        }

        // GET /Posts?Query=..&Type=..&CategoryId=..&CampusId=..&Page=..
        [AllowAnonymous]
        public ActionResult Index(string query, string type, int? categoryId, int? campusId, int page = 1)
        {
            return View(_posts.Search(query, type, categoryId, campusId, page));
        }

        // GET /Posts/Details/5
        [AllowAnonymous]
        public ActionResult Details(int id)
        {
            var vm = _posts.GetDetails(id, CurrentUserIdOrNull, IsAdmin);
            if (vm == null) return HttpNotFound();
            return View(vm);
        }

        // GET /Posts/Create?type=Lost|Found
        [HttpGet, Authorize]
        public ActionResult Create(string type)
        {
            var vm = new PostFormVm { PostType = (type == "Found") ? "Found" : "Lost" };
            _posts.FillLookups(vm);
            return View(vm);
        }

        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult Create(PostFormVm vm)
        {
            foreach (var e in _posts.ValidateForm(vm)) ModelState.AddModelError(e.Key, e.Value);
            if (!ModelState.IsValid) { _posts.FillLookups(vm); return View(vm); }

            var result = _posts.Create(vm, CurrentUserId);
            if (!result.Ok)
            {
                ModelState.AddModelError("", result.Message);
                _posts.FillLookups(vm);
                return View(vm);
            }

            // Tinh va luu goi y ngay sau khi dang (loi o day khong duoc lam hong viec dang tin)
            try { _matches.GetCandidatesAndCache(result.Id.Value, 10); } catch { }

            TempData["Success"] = "Đã đăng tin. Bấm 'Xem tin tương đồng' để xem gợi ý.";
            return RedirectToAction("Details", new { id = result.Id.Value });
        }

        // GET /Posts/Edit/5
        [HttpGet, Authorize]
        public ActionResult Edit(int id)
        {
            var post = Db.Posts.Find(id);
            if (post == null || post.IsDeleted) return HttpNotFound();
            if (post.AuthorUserId != CurrentUserId && !IsAdmin) return Forbidden();
            if (post.Status != "Open")
            {
                TempData["Error"] = "Chỉ sửa được tin đang mở.";
                return RedirectToAction("Details", new { id });
            }
            return View(_posts.BuildEditVm(id));
        }

        // POST /Posts/Edit  (Id nam trong hidden field; quyen luon kiem tra lai theo DB)
        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult Edit(PostFormVm vm)
        {
            if (!vm.Id.HasValue) return HttpNotFound();
            foreach (var e in _posts.ValidateForm(vm)) ModelState.AddModelError(e.Key, e.Value);
            if (!ModelState.IsValid) { _posts.FillLookups(vm); return View(vm); }

            var result = _posts.Update(vm, CurrentUserId, IsAdmin);
            if (result.NotFound) return HttpNotFound();
            if (result.Forbidden) return Forbidden();
            if (!result.Ok)
            {
                ModelState.AddModelError("", result.Message);
                _posts.FillLookups(vm);
                return View(vm);
            }

            try { _matches.GetCandidatesAndCache(vm.Id.Value, 10); } catch { }
            TempData["Success"] = result.Message;
            return RedirectToAction("Details", new { id = vm.Id.Value });
        }

        // POST /Posts/Close  (dong tin)
        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult Close(int id)
        {
            var result = _posts.Close(id, CurrentUserId, IsAdmin);
            if (result.NotFound) return HttpNotFound();
            if (result.Forbidden) return Forbidden();
            if (result.Ok) TempData["Success"] = result.Message; else TempData["Error"] = result.Message;
            return RedirectToAction("Details", new { id });
        }

        // GET /Posts/Mine
        [Authorize]
        public ActionResult Mine()
        {
            return View(_posts.GetMine(CurrentUserId));
        }
    }
}
