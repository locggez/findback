using System.Linq;
using System.Web.Mvc;
using FindBack.Web.Services;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : BaseController
    {
        private readonly PostService _posts;
        public AdminController() { _posts = new PostService(Db); }

        // GET /Admin
        public ActionResult Index()
        {
            var vm = new AdminIndexVm
            {
                OpenPostCount = Db.Posts.Count(p => !p.IsDeleted && p.Status == "Open"),
                ResolvedPostCount = Db.Posts.Count(p => !p.IsDeleted && p.Status == "Resolved"),
                RecentPosts = _posts.GetRecent(6),
                Categories = Db.Categories.Where(c => c.IsActive).OrderBy(c => c.Name).ToList()
                    .Select(c => new AdminCategoryVm { Id = c.CategoryId, Name = c.Name }).ToList(),
                Users = (from u in Db.Users
                         join r in Db.Roles on u.RoleId equals r.RoleId
                         orderby u.CreatedAt descending
                         select new AdminUserVm
                         {
                             Id = u.UserId, DisplayName = u.DisplayName, Email = u.Email,
                             Role = r.Name, IsActive = u.IsActive
                         }).ToList()
            };
            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult CreateCategory(string name)
        {
            name = (name ?? "").Trim();
            if (name.Length < 2 || name.Length > 45)
            {
                TempData["Error"] = "Tên danh mục phải từ 2 đến 45 ký tự.";
                return RedirectToAction("Index");
            }

            var existing = Db.Categories.FirstOrDefault(c => c.Name == name);
            if (existing != null)
            {
                if (existing.IsActive) { TempData["Error"] = "Danh mục đã tồn tại."; }
                else { existing.IsActive = true; Db.SaveChanges(); TempData["Success"] = "Đã bật lại danh mục."; }
                return RedirectToAction("Index");
            }

            Db.Categories.Add(new Category { Name = name, IsActive = true });
            Db.SaveChanges();
            TempData["Success"] = "Đã thêm danh mục.";
            return RedirectToAction("Index");
        }

        // Khong xoa cung vi bai dang dang tham chieu -> chuyen sang ngung su dung
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult DeactivateCategory(int id)
        {
            var cat = Db.Categories.Find(id);
            if (cat == null) return HttpNotFound();
            cat.IsActive = false;
            Db.SaveChanges();
            TempData["Success"] = "Đã ngưng sử dụng danh mục.";
            return RedirectToAction("Index");
        }

        // Khoa / mo khoa tai khoan (khong cho tu khoa chinh minh)
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult ToggleUser(int id)
        {
            if (id == CurrentUserId)
            {
                TempData["Error"] = "Bạn không thể tự khóa tài khoản của mình.";
                return RedirectToAction("Index");
            }
            var user = Db.Users.Find(id);
            if (user == null) return HttpNotFound();
            user.IsActive = !user.IsActive;
            Db.SaveChanges();
            TempData["Success"] = user.IsActive ? "Đã mở khóa tài khoản." : "Đã khóa tài khoản.";
            return RedirectToAction("Index");
        }
    }
}
