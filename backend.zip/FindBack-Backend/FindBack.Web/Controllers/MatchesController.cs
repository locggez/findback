using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using FindBack.Web.Services;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Controllers
{
    public class MatchesController : BaseController
    {
        private readonly PostService _posts;
        private readonly MatchService _matches;

        public MatchesController()
        {
            _posts = new PostService(Db);
            _matches = new MatchService(Db);
        }

        // GET /Matches/ForPost/5  - goi y cho tin cua CHINH MINH (hoac Admin)
        [Authorize]
        public ActionResult ForPost(int id)
        {
            var post = Db.Posts.Find(id);
            if (post == null || post.IsDeleted) return HttpNotFound();
            if (post.AuthorUserId != CurrentUserId && !IsAdmin) return Forbidden();

            var vm = new MatchesVm { SourcePostId = post.PostId, SourceTitle = post.Title };
            if (post.Status != "Open") return View(vm);   // tin da dong/xong -> khong goi y

            List<MatchResult> results = _matches.GetCandidatesAndCache(id, 10);
            var cards = _posts.GetCards(results.Select(r => r.CandidatePostId));
            foreach (var r in results)
            {
                PostCardVm card;
                if (!cards.TryGetValue(r.CandidatePostId, out card)) continue;
                vm.Suggestions.Add(new MatchSuggestionVm { Post = card, Score = r.Score, Reasons = r.Reasons });
            }
            return View(vm);
        }
    }
}
