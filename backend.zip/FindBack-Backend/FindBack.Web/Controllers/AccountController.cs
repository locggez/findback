using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using FindBack.Web.Services;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Controllers
{
    public class AccountController : BaseController
    {
        private readonly AccountService _accounts;
        public AccountController() { _accounts = new AccountService(Db); }

        // ---------- Dang nhap ----------
        [HttpGet, AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            if (Request.IsAuthenticated) return RedirectToAction("Index", "Home");
            TempData["ReturnUrl"] = returnUrl;   // form Razor khong mang returnUrl nen luu tam o day
            return View(new LoginVm());
        }

        [HttpPost, AllowAnonymous, ValidateAntiForgeryToken]
        public ActionResult Login(LoginVm vm)
        {
            if (!ModelState.IsValid) { TempData.Keep("ReturnUrl"); return View(vm); }

            var result = _accounts.Authenticate(vm.Email, vm.Password);
            if (!result.Succeeded)
            {
                ModelState.AddModelError("", result.Error);
                TempData.Keep("ReturnUrl");
                return View(vm);
            }

            SignIn(result.UserId, result.Role);
            var returnUrl = TempData["ReturnUrl"] as string;
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        // ---------- Dang ky ----------
        [HttpGet, AllowAnonymous]
        public ActionResult Register()
        {
            if (Request.IsAuthenticated) return RedirectToAction("Index", "Home");
            return View(new RegisterVm());
        }

        [HttpPost, AllowAnonymous, ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVm vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var result = _accounts.Register(vm);
            if (!result.Succeeded)
            {
                ModelState.AddModelError("Email", result.Error);
                return View(vm);
            }
            SignIn(result.UserId, result.Role);
            TempData["Success"] = "Tạo tài khoản thành công. Chào mừng bạn đến với FindBack!";
            return RedirectToAction("Index", "Home");
        }

        // ---------- Dang xuat (POST, khong dung GET) ----------
        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        // ---------- Ho so ----------
        [HttpGet, Authorize]
        public ActionResult Profile()
        {
            var vm = _accounts.GetProfile(CurrentUserId);
            if (vm == null) return HttpNotFound();
            return View(vm);
        }

        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult Profile(ProfileVm vm)
        {
            // UserId luon lay tu phien dang nhap, KHONG lay tu form
            var current = _accounts.GetProfile(CurrentUserId);
            if (current == null) return HttpNotFound();
            vm.Email = current.Email;
            if (!ModelState.IsValid) return View(vm);

            _accounts.UpdateProfile(CurrentUserId, vm.DisplayName);
            TempData["Success"] = "Đã cập nhật hồ sơ.";
            return RedirectToAction("Profile");
        }

        // Tao cookie dang nhap: Name = UserId, UserData = ten vai tro
        private void SignIn(int userId, string role)
        {
            var now = DateTime.Now;
            var ticket = new FormsAuthenticationTicket(1, userId.ToString(), now, now.AddMinutes(60), false, role);
            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket))
            {
                HttpOnly = true,
                Secure = Request.IsSecureConnection
            };
            Response.Cookies.Add(cookie);
        }
    }
}
