using System.Web.Mvc;
using FindBack.Web.Services;

namespace FindBack.Web.Controllers
{
    [Authorize]
    public class HandoversController : BaseController
    {
        private readonly HandoverService _handovers;
        public HandoversController() { _handovers = new HandoverService(Db); }

        // POST /Handovers/Confirm  (id = HandoverId)
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Confirm(int id)
        {
            return Respond(_handovers.Confirm(id, CurrentUserId));
        }

        // POST /Handovers/Dispute
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Dispute(int id)
        {
            return Respond(_handovers.Dispute(id, CurrentUserId));
        }

        private ActionResult Respond(ServiceResult result)
        {
            if (result.NotFound) return HttpNotFound();
            if (result.Forbidden) return Forbidden();
            if (result.Ok) TempData["Success"] = result.Message; else TempData["Error"] = result.Message;
            return RedirectToAction("Mine", "Claims");
        }
    }
}
