using System.Web.Mvc;
using FindBack.Web.Services;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Controllers
{
    [Authorize]
    public class ClaimsController : BaseController
    {
        private readonly ClaimService _claims;
        public ClaimsController() { _claims = new ClaimService(Db); }

        // GET /Claims/Create?foundPostId=5
        [HttpGet]
        public ActionResult Create(int foundPostId)
        {
            string error = _claims.CheckCanClaim(foundPostId, CurrentUserId);
            if (error != null)
            {
                TempData["Error"] = error;
                return RedirectToAction("Details", "Posts", new { id = foundPostId });
            }
            return View(_claims.BuildCreateVm(foundPostId, CurrentUserId));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Create(ClaimCreateVm vm)
        {
            if (!ModelState.IsValid) { _claims.FillCreateVm(vm, CurrentUserId); return View(vm); }

            var result = _claims.Create(vm, CurrentUserId);   // service tu kiem tra lai moi dieu kien
            if (!result.Ok)
            {
                ModelState.AddModelError("", result.Message);
                _claims.FillCreateVm(vm, CurrentUserId);
                return View(vm);
            }
            TempData["Success"] = result.Message;
            return RedirectToAction("Mine");
        }

        // GET /Claims/Mine  - ca "toi gui" lan "gui den toi"
        [HttpGet]
        public ActionResult Mine()
        {
            return View(_claims.GetDashboard(CurrentUserId));
        }

        // POST /Claims/Review  (id + decision = Approved | Rejected)
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Review(int id, string decision)
        {
            return Respond(_claims.Review(id, decision, CurrentUserId));
        }

        // POST /Claims/Withdraw
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Withdraw(int id)
        {
            return Respond(_claims.Withdraw(id, CurrentUserId));
        }

        private ActionResult Respond(ServiceResult result)
        {
            if (result.NotFound) return HttpNotFound();
            if (result.Forbidden) return Forbidden();
            if (result.Ok) TempData["Success"] = result.Message; else TempData["Error"] = result.Message;
            return RedirectToAction("Mine");
        }
    }
}
