/* FindBack Razor UI enhancement: no authentication, storage or business decisions here. */
(function(){
  "use strict";
  const nav=document.getElementById("mvc-nav");
  const toggle=document.getElementById("mvc-menu-toggle");
  if(nav&&toggle){
    toggle.addEventListener("click",()=>{
      const expanded=toggle.getAttribute("aria-expanded")==="true";
      toggle.setAttribute("aria-expanded",String(!expanded));
      nav.classList.toggle("is-open",!expanded);
    });
  }
  const campus=document.querySelector("[data-campus-select]");
  const location=document.querySelector("[data-location-select]");
  if(campus&&location){
    // The server must validate CampusId/LocationId on POST.
    const applyCampusFilter=(resetValue)=>{
      const selected=campus.value;
      [...location.options].forEach(opt=>{
        const campusOfOption=opt.getAttribute("data-campus");
        opt.hidden=!!campusOfOption && campusOfOption!==selected;
        opt.disabled=!!campusOfOption && campusOfOption!==selected;
      });
      if(resetValue){
        const enabled=[...location.options].find(o=>!o.disabled);
        if(enabled)location.value=enabled.value;
      }
    };
    campus.addEventListener("change",()=>applyCampusFilter(true));
    applyCampusFilter(false);
  }
  const imageInput=document.querySelector("[data-image-preview]");
  const imageOutput=document.getElementById("mvc-image-preview");
  let lastUrl=null;
  if(imageInput&&imageOutput){
    imageInput.addEventListener("change",()=>{
      if(lastUrl){URL.revokeObjectURL(lastUrl);lastUrl=null;}
      imageOutput.replaceChildren();
      const f=imageInput.files?.[0];if(!f)return;
      if(!["image/png","image/jpeg","image/webp"].includes(f.type)||f.size>3*1024*1024){
        imageInput.value="";imageOutput.textContent="Chỉ chọn ảnh JPG/PNG/WebP tối đa 3MB.";return;
      }
      lastUrl=URL.createObjectURL(f);
      const img=document.createElement("img");
      img.className="findback-photo-preview";img.src=lastUrl;img.alt="Ảnh đồ vật vừa chọn (chỉ xem trước)";
      imageOutput.appendChild(img);
    });
    window.addEventListener("pagehide",()=>{if(lastUrl)URL.revokeObjectURL(lastUrl);});
  }
  document.querySelectorAll("form[data-confirm]").forEach(form=>{
    form.addEventListener("submit",event=>{
      if(!window.confirm(form.dataset.confirm || "Bạn có chắc chắn?"))event.preventDefault();
    });
  });
  const postForm=document.querySelector("[data-post-form]");
  const previewBtn=document.querySelector("[data-post-preview-button]");
  const preview=document.getElementById("mvc-post-preview");
  if(postForm&&previewBtn&&preview){
    previewBtn.addEventListener("click",()=>{
      const title=postForm.querySelector('[name="Title"]')?.value||"Chưa nhập tiêu đề";
      const text=postForm.querySelector('[name="PublicDescription"]')?.value||"Chưa nhập mô tả";
      const name=preview.querySelector("[data-preview-title]");
      const desc=preview.querySelector("[data-preview-description]");
      if(name)name.textContent=title;
      if(desc)desc.textContent=text;
      preview.hidden=false;preview.scrollIntoView({block:"nearest",behavior:"smooth"});
    });
  }
})();
