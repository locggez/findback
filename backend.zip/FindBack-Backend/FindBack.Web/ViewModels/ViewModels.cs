using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace FindBack.Web.ViewModels
{
    // ViewModel = "hop du lieu" gui giua Controller va View. Khong dung entity EF truc tiep lam form.

    public class PostCardVm
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string PostType { get; set; }
        public string CategoryName { get; set; }
        public string CampusName { get; set; }
        public string LocationName { get; set; }
        public DateTime HappenedAt { get; set; }
        public string Status { get; set; }
    }

    public class PostsIndexVm
    {
        public string Query { get; set; }
        public string Type { get; set; }
        public int? CategoryId { get; set; }
        public int? CampusId { get; set; }
        public IList<PostCardVm> Posts { get; set; } = new List<PostCardVm>();
        public IEnumerable<SelectListItem> Categories { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Campuses { get; set; } = new List<SelectListItem>();
        public int Page { get; set; } = 1;
        public int PageCount { get; set; } = 1;
    }

    public class LocationOptionVm
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CampusId { get; set; }
    }

    public class PostFormVm
    {
        public int? Id { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn loại tin."),
         RegularExpression("^(Lost|Found)$", ErrorMessage = "Loại tin không hợp lệ.")]
        public string PostType { get; set; } = "Lost";

        [Required(ErrorMessage = "Vui lòng nhập tiêu đề."),
         StringLength(100, MinimumLength = 5, ErrorMessage = "Tiêu đề từ 5 đến 100 ký tự.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn danh mục.")]
        public int? CategoryId { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn cơ sở.")]
        public int? CampusId { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn khu vực.")]
        public int? LocationId { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập thời gian.")]
        public DateTime? HappenedAt { get; set; }

        [StringLength(40, ErrorMessage = "Màu sắc tối đa 40 ký tự.")]
        public string Color { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập mô tả."),
         StringLength(1000, MinimumLength = 15, ErrorMessage = "Mô tả từ 15 đến 1000 ký tự.")]
        public string PublicDescription { get; set; }

        public IEnumerable<SelectListItem> Categories { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Campuses { get; set; } = new List<SelectListItem>();
        public IEnumerable<SelectListItem> Locations { get; set; } = new List<SelectListItem>();
        // Tat ca khu vuc kem CampusId de JS loc theo co so (xem _PostForm.cshtml)
        public IList<LocationOptionVm> LocationOptions { get; set; } = new List<LocationOptionVm>();
    }

    public class PostDetailsVm : PostCardVm
    {
        public string PublicDescription { get; set; }
        public string Color { get; set; }
        public string AuthorDisplayName { get; set; }
        public bool CanEdit { get; set; }
        public bool CanClaim { get; set; }
        public bool CanSeeMatches { get; set; }
    }

    public class MatchSuggestionVm
    {
        public PostCardVm Post { get; set; } = new PostCardVm();
        public int Score { get; set; }
        public IList<string> Reasons { get; set; } = new List<string>();
    }

    public class MatchesVm
    {
        public int SourcePostId { get; set; }
        public string SourceTitle { get; set; }
        public IList<MatchSuggestionVm> Suggestions { get; set; } = new List<MatchSuggestionVm>();
    }

    public class ClaimCreateVm
    {
        [Required] public int FoundPostId { get; set; }
        public string FoundPostTitle { get; set; }
        public int? RelatedLostPostId { get; set; }
        public IEnumerable<SelectListItem> MyLostPosts { get; set; } = new List<SelectListItem>();

        [Required(ErrorMessage = "Vui lòng mô tả đặc điểm riêng để xác minh."),
         StringLength(600, MinimumLength = 12, ErrorMessage = "Đặc điểm riêng từ 12 đến 600 ký tự.")]
        public string PrivateProof { get; set; }
    }

    public class ClaimRowVm
    {
        public int Id { get; set; }
        public int FoundPostId { get; set; }
        public string FoundPostTitle { get; set; }
        public string Status { get; set; }
        public string PrivateProof { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool CanReview { get; set; }
        public bool CanWithdraw { get; set; }
        public bool CanConfirm { get; set; }
        public bool CanDispute { get; set; }
        public bool FinderConfirmed { get; set; }
        public bool ClaimantConfirmed { get; set; }
        public string HandoverStatus { get; set; }
        public int? HandoverId { get; set; }
    }

    public class ClaimDashboardVm
    {
        public IList<ClaimRowVm> Outgoing { get; set; } = new List<ClaimRowVm>();
        public IList<ClaimRowVm> Incoming { get; set; } = new List<ClaimRowVm>();
    }

    public class LoginVm
    {
        [Required(ErrorMessage = "Vui lòng nhập email."), EmailAddress(ErrorMessage = "Email không hợp lệ.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu."), DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class RegisterVm
    {
        [Required(ErrorMessage = "Vui lòng nhập tên hiển thị."),
         StringLength(60, MinimumLength = 2, ErrorMessage = "Tên hiển thị từ 2 đến 60 ký tự.")]
        public string DisplayName { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập email."),
         EmailAddress(ErrorMessage = "Email không hợp lệ."),
         StringLength(256)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu."),
         MinLength(8, ErrorMessage = "Mật khẩu tối thiểu 8 ký tự."), DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập lại mật khẩu."),
         System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "Mật khẩu xác nhận không khớp."),
         DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }

    public class ProfileVm
    {
        [Required(ErrorMessage = "Vui lòng nhập tên hiển thị."),
         StringLength(60, MinimumLength = 2, ErrorMessage = "Tên hiển thị từ 2 đến 60 ký tự.")]
        public string DisplayName { get; set; }
        public string Email { get; set; }
    }

    public class AdminCategoryVm { public int Id { get; set; } public string Name { get; set; } }

    public class AdminUserVm
    {
        public int Id { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
    }

    public class AdminIndexVm
    {
        public int OpenPostCount { get; set; }
        public int ResolvedPostCount { get; set; }
        public IList<PostCardVm> RecentPosts { get; set; } = new List<PostCardVm>();
        public IList<AdminCategoryVm> Categories { get; set; } = new List<AdminCategoryVm>();
        public IList<AdminUserVm> Users { get; set; } = new List<AdminUserVm>();
    }
}
