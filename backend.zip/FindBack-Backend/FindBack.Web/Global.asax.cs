using System;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace FindBack.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            // Chong gia mao form (AntiForgeryToken) can biet claim nao dinh danh user
            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.Name;
        }

        // Moi request: doc cookie dang nhap -> dung doi tuong User (kem vai tro) cho [Authorize(Roles=...)]
        protected void Application_PostAuthenticateRequest(object sender, EventArgs e)
        {
            var cookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (cookie == null || string.IsNullOrEmpty(cookie.Value)) return;
            try
            {
                var ticket = FormsAuthentication.Decrypt(cookie.Value);
                if (ticket == null || ticket.Expired) return;
                var roles = string.IsNullOrEmpty(ticket.UserData) ? new string[0] : new[] { ticket.UserData };
                Context.User = new GenericPrincipal(new GenericIdentity(ticket.Name, "Forms"), roles);
            }
            catch (Exception)
            {
                // Cookie hong / bi sua -> coi nhu chua dang nhap
            }
        }
    }
}
