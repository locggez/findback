using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web.Mvc;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Services
{
    /// <summary>Nghiep vu Claim (yeu cau nhan lai do): tao, duyet, rut, bang theo doi.</summary>
    public class ClaimService
    {
        public const int MaxClaimsPerDay = 10;

        private readonly FindBackEntities db;
        public ClaimService(FindBackEntities db) { this.db = db; }

        // ---------------- Kiem tra co duoc gui claim khong ----------------
        /// <summary>Tra ve null neu duoc phep, nguoc lai tra ve thong bao loi.</summary>
        public string CheckCanClaim(int foundPostId, int userId)
        {
            var found = db.Posts.FirstOrDefault(p => p.PostId == foundPostId && !p.IsDeleted);
            if (found == null) return "Không tìm thấy tin nhặt được.";
            if (found.PostType != "Found") return "Chỉ gửi yêu cầu nhận cho tin 'Nhặt được'.";
            if (found.Status != "Open") return "Tin này không còn nhận yêu cầu.";
            if (found.AuthorUserId == userId) return "Bạn không thể gửi yêu cầu cho tin do chính mình đăng.";

            bool approvedExists = db.Claims.Any(c => c.FoundPostId == foundPostId && c.Status == "Approved");
            if (approvedExists) return "Tin này đang trong quá trình bàn giao cho người khác.";

            bool duplicate = db.Claims.Any(c => c.FoundPostId == foundPostId && c.ClaimantUserId == userId
                                                && (c.Status == "Pending" || c.Status == "Approved"));
            if (duplicate) return "Bạn đã gửi yêu cầu cho tin này rồi.";

            var since = DateTime.Now.AddDays(-1);
            int today = db.Claims.Count(c => c.ClaimantUserId == userId && c.CreatedAt >= since);
            if (today >= MaxClaimsPerDay) return "Bạn đã gửi quá nhiều yêu cầu trong 24 giờ. Vui lòng thử lại sau.";
            return null;
        }

        public ClaimCreateVm BuildCreateVm(int foundPostId, int userId)
        {
            var vm = new ClaimCreateVm { FoundPostId = foundPostId };
            FillCreateVm(vm, userId);
            return vm;
        }

        public void FillCreateVm(ClaimCreateVm vm, int userId)
        {
            int fid = vm.FoundPostId;
            vm.FoundPostTitle = db.Posts.Where(p => p.PostId == fid).Select(p => p.Title).FirstOrDefault();
            vm.MyLostPosts = db.Posts
                .Where(p => p.AuthorUserId == userId && p.PostType == "Lost" && p.Status == "Open" && !p.IsDeleted)
                .OrderByDescending(p => p.CreatedAt).ToList()
                .Select(p => new SelectListItem { Value = p.PostId.ToString(), Text = p.Title }).ToList();
        }

        // ---------------- Tao claim ----------------
        public ServiceResult Create(ClaimCreateVm vm, int userId)
        {
            string error = CheckCanClaim(vm.FoundPostId, userId);
            if (error != null) return ServiceResult.Fail(error);

            if (vm.RelatedLostPostId.HasValue)
            {
                int lostId = vm.RelatedLostPostId.Value;
                // Tin Lost lien ket phai la tin Lost cua CHINH nguoi gui
                bool ok = db.Posts.Any(p => p.PostId == lostId && p.PostType == "Lost"
                                            && p.AuthorUserId == userId && !p.IsDeleted);
                if (!ok) return ServiceResult.Fail("Tin mất đồ liên kết không hợp lệ.");
            }

            var claim = new Claim
            {
                FoundPostId = vm.FoundPostId,
                ClaimantUserId = userId,
                RelatedLostPostId = vm.RelatedLostPostId,
                PrivateProof = vm.PrivateProof.Trim(),
                Status = "Pending",
                CreatedAt = DateTime.Now
            };
            db.Claims.Add(claim);
            db.SaveChanges();
            return ServiceResult.Success("Đã gửi yêu cầu nhận đồ. Chờ người giữ đồ xem xét.", claim.ClaimId);
        }

        // ---------------- Duyet claim (Approve / Reject) ----------------
        public ServiceResult Review(int claimId, string decision, int userId)
        {
            if (decision != "Approved" && decision != "Rejected")
                return ServiceResult.Fail("Quyết định không hợp lệ.");

            using (var tx = db.Database.BeginTransaction())
            {
                var claim = db.Claims.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null) return ServiceResult.Missing();

                var found = db.Posts.FirstOrDefault(p => p.PostId == claim.FoundPostId);
                // Chi CHU tin Found moi duoc duyet
                if (found == null || found.AuthorUserId != userId) return ServiceResult.Deny();

                if (claim.Status != "Pending") return ServiceResult.Fail("Yêu cầu này đã được xử lý.");
                if (found.IsDeleted || found.Status != "Open") return ServiceResult.Fail("Tin nhặt được không còn mở.");

                var now = DateTime.Now;
                claim.ReviewedAt = now;
                claim.ReviewedByUserId = userId;

                if (decision == "Rejected")
                {
                    claim.Status = "Rejected";
                    db.SaveChanges();
                    tx.Commit();
                    return ServiceResult.Success("Đã từ chối yêu cầu.");
                }

                // Approve: kiem tra lai trong transaction (chong 2 nguoi cung duoc duyet)
                int thisId = claim.ClaimId, foundId = found.PostId;
                bool otherApproved = db.Claims.Any(c => c.FoundPostId == foundId && c.Status == "Approved" && c.ClaimId != thisId);
                if (otherApproved) return ServiceResult.Fail("Tin này đã chấp nhận một yêu cầu khác.");

                claim.Status = "Approved";
                db.Handovers.Add(new Handover { ClaimId = claim.ClaimId, Status = "Pending", CreatedAt = now });
                try
                {
                    db.SaveChanges();   // unique index UX_Claims_OneApprovedPerFound la lop bao ve cuoi
                    tx.Commit();
                }
                catch (DbUpdateException)
                {
                    tx.Rollback();
                    return ServiceResult.Fail("Có yêu cầu khác vừa được chấp nhận. Vui lòng tải lại trang.");
                }
                return ServiceResult.Success("Đã chấp nhận. Hãy hẹn gặp ở nơi công cộng rồi cùng xác nhận bàn giao.");
            }
        }

        // ---------------- Rut claim ----------------
        public ServiceResult Withdraw(int claimId, int userId)
        {
            var claim = db.Claims.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim == null) return ServiceResult.Missing();
            if (claim.ClaimantUserId != userId) return ServiceResult.Deny();
            if (claim.Status != "Pending") return ServiceResult.Fail("Chỉ rút được yêu cầu đang chờ xét.");
            claim.Status = "Withdrawn";
            db.SaveChanges();
            return ServiceResult.Success("Đã rút yêu cầu.");
        }

        // ---------------- Bang theo doi (gui di / gui den) ----------------
        private class ClaimJoin
        {
            public int ClaimId { get; set; }
            public int FoundPostId { get; set; }
            public string Title { get; set; }
            public string Status { get; set; }
            public string PrivateProof { get; set; }
            public DateTime CreatedAt { get; set; }
            public int? HandoverId { get; set; }
            public string HandoverStatus { get; set; }
            public DateTime? FinderConfirmedAt { get; set; }
            public DateTime? ClaimantConfirmedAt { get; set; }
        }

        public ClaimDashboardVm GetDashboard(int userId)
        {
            var outgoing = (from c in db.Claims
                            join p in db.Posts on c.FoundPostId equals p.PostId
                            join h in db.Handovers on c.ClaimId equals h.ClaimId into hs
                            from hh in hs.DefaultIfEmpty()
                            where c.ClaimantUserId == userId
                            orderby c.CreatedAt descending
                            select new ClaimJoin
                            {
                                ClaimId = c.ClaimId, FoundPostId = c.FoundPostId, Title = p.Title,
                                Status = c.Status, PrivateProof = c.PrivateProof, CreatedAt = c.CreatedAt,
                                HandoverId = (int?)hh.HandoverId, HandoverStatus = hh.Status,
                                FinderConfirmedAt = hh.FinderConfirmedAt, ClaimantConfirmedAt = hh.ClaimantConfirmedAt
                            }).ToList();

            var incoming = (from c in db.Claims
                            join p in db.Posts on c.FoundPostId equals p.PostId
                            join h in db.Handovers on c.ClaimId equals h.ClaimId into hs
                            from hh in hs.DefaultIfEmpty()
                            where p.AuthorUserId == userId
                            orderby c.CreatedAt descending
                            select new ClaimJoin
                            {
                                ClaimId = c.ClaimId, FoundPostId = c.FoundPostId, Title = p.Title,
                                Status = c.Status, PrivateProof = c.PrivateProof, CreatedAt = c.CreatedAt,
                                HandoverId = (int?)hh.HandoverId, HandoverStatus = hh.Status,
                                FinderConfirmedAt = hh.FinderConfirmedAt, ClaimantConfirmedAt = hh.ClaimantConfirmedAt
                            }).ToList();

            return new ClaimDashboardVm
            {
                Outgoing = outgoing.Select(r => ToRow(r, false)).ToList(),
                Incoming = incoming.Select(r => ToRow(r, true)).ToList()
            };
        }

        private static ClaimRowVm ToRow(ClaimJoin r, bool isFinder)
        {
            bool handoverPending = r.HandoverStatus == "Pending";
            bool myConfirmed = isFinder ? r.FinderConfirmedAt.HasValue : r.ClaimantConfirmedAt.HasValue;
            return new ClaimRowVm
            {
                Id = r.ClaimId, FoundPostId = r.FoundPostId, FoundPostTitle = r.Title, Status = r.Status,
                // PrivateProof CHI tra ve cho nguoi giu do (finder); claimant tu biet bang chung cua minh
                PrivateProof = isFinder ? r.PrivateProof : null,
                CreatedAt = r.CreatedAt,
                CanReview = isFinder && r.Status == "Pending",
                CanWithdraw = !isFinder && r.Status == "Pending",
                CanConfirm = handoverPending && !myConfirmed,
                CanDispute = handoverPending,
                FinderConfirmed = r.FinderConfirmedAt.HasValue,
                ClaimantConfirmed = r.ClaimantConfirmedAt.HasValue,
                HandoverStatus = r.HandoverStatus,
                HandoverId = r.HandoverId
            };
        }
    }
}
