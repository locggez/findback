using System;
using System.Security.Cryptography;

namespace FindBack.Web.Services
{
    /// <summary>
    /// Bam mat khau bang PBKDF2-SHA256 + salt ngau nhien. Dinh dang luu DB:
    /// v1.{iterations}.{salt base64}.{hash base64}
    /// Can .NET Framework 4.7.2+ (du an nen chon 4.8).
    /// </summary>
    public static class PasswordHasher
    {
        private const int SaltSize = 16;
        private const int KeySize = 32;
        private const int Iterations = 100000;

        public static string Hash(string password)
        {
            var salt = new byte[SaltSize];
            using (var rng = new RNGCryptoServiceProvider()) { rng.GetBytes(salt); }
            var key = Derive(password, salt, Iterations);
            return "v1." + Iterations + "." + Convert.ToBase64String(salt) + "." + Convert.ToBase64String(key);
        }

        public static bool Verify(string password, string stored)
        {
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(stored)) return false;
            var parts = stored.Split('.');
            if (parts.Length != 4 || parts[0] != "v1") return false;

            int iterations;
            if (!int.TryParse(parts[1], out iterations) || iterations < 1000 || iterations > 1000000) return false;

            byte[] salt, expected;
            try
            {
                salt = Convert.FromBase64String(parts[2]);
                expected = Convert.FromBase64String(parts[3]);
            }
            catch (FormatException) { return false; }

            var actual = Derive(password, salt, iterations);
            return FixedTimeEquals(expected, actual);
        }

        private static byte[] Derive(string password, byte[] salt, int iterations)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
            {
                return pbkdf2.GetBytes(KeySize);
            }
        }

        // So sanh thoi gian co dinh, tranh timing attack
        private static bool FixedTimeEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
