using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Linq;
using System.Text;

namespace FindBack.Web.Services
{
    /// <summary>Thong tin toi thieu cua 1 tin de cham diem (KHONG chua PrivateProof/email/MSSV).</summary>
    public class PostInfo
    {
        public int Id { get; set; }
        public int AuthorUserId { get; set; }
        public string PostType { get; set; }
        public int CategoryId { get; set; }
        public int LocationId { get; set; }
        public int CampusId { get; set; }
        public DateTime HappenedAt { get; set; }
        public string Color { get; set; }
        public string Title { get; set; }
        public string PublicDescription { get; set; }
    }

    public class MatchResult
    {
        public int CandidatePostId { get; set; }
        public int Score { get; set; }
        public List<string> Reasons { get; set; } = new List<string>();
        public DateTime HappenedAt { get; set; }
        public string AlgorithmVersion { get; set; }
    }

    /// <summary>
    /// Smart Matching v1 (rule-based, KHONG phai AI da huan luyen).
    /// Diem toi da 100: Danh muc 30 + Dia diem 25 + Thoi gian 20 + Mau 10 + Mo ta 15.
    /// </summary>
    public class MatchService
    {
        public const string AlgorithmVersion = "rule-v1";
        // Nguong hien thi tren UI. Tai lieu goi y 40, nhung khi thu voi cac mau trong docs/07:
        // cap SAI (khac co so/cach vai thang = 46, vi vs tai nghe cung cho = 45) van lot qua 40,
        // con cap DUNG dat 87-91 -> chon 50. Day la gia tri thu nghiem tren it mau, can hieu chinh them.
        public const int MinimumScore = 50;
        public const int MaxCandidatesToScore = 500;

        private readonly FindBackEntities db;
        public MatchService(FindBackEntities db) { this.db = db; }

        // ---------------------------------------------------------------
        // 1) Lay ung vien tu DB
        // ---------------------------------------------------------------
        public PostInfo LoadInfo(int postId)
        {
            return (from p in db.Posts
                    join l in db.Locations on p.LocationId equals l.LocationId
                    where p.PostId == postId && !p.IsDeleted
                    select new PostInfo
                    {
                        Id = p.PostId, AuthorUserId = p.AuthorUserId, PostType = p.PostType,
                        CategoryId = p.CategoryId, LocationId = p.LocationId, CampusId = l.CampusId,
                        HappenedAt = p.HappenedAt, Color = p.Color, Title = p.Title,
                        PublicDescription = p.PublicDescription
                    }).FirstOrDefault();
        }

        public List<MatchResult> GetCandidates(int postId, int maxResults)
        {
            var source = LoadInfo(postId);
            if (source == null) return new List<MatchResult>();

            var opposite = source.PostType == "Lost" ? "Found" : "Lost";
            int authorId = source.AuthorUserId;

            // Chi lay tin DOI LAP loai, dang Open, chua xoa, khong phai cua chinh minh
            var candidates = (from p in db.Posts
                              join l in db.Locations on p.LocationId equals l.LocationId
                              where p.PostType == opposite && p.Status == "Open" && !p.IsDeleted
                                    && p.PostId != postId && p.AuthorUserId != authorId
                              orderby p.HappenedAt descending
                              select new PostInfo
                              {
                                  Id = p.PostId, AuthorUserId = p.AuthorUserId, PostType = p.PostType,
                                  CategoryId = p.CategoryId, LocationId = p.LocationId, CampusId = l.CampusId,
                                  HappenedAt = p.HappenedAt, Color = p.Color, Title = p.Title,
                                  PublicDescription = p.PublicDescription
                              }).Take(MaxCandidatesToScore).ToList();

            return candidates
                .Select(c => Score(source, c))
                .Where(r => r.Score >= MinimumScore)
                .OrderByDescending(r => r.Score)
                .ThenByDescending(r => r.HappenedAt)
                .Take(maxResults)
                .ToList();
        }

        /// <summary>Tinh ung vien roi luu cache vao bang MatchSuggestions.</summary>
        public List<MatchResult> GetCandidatesAndCache(int postId, int maxResults)
        {
            var results = GetCandidates(postId, maxResults);
            var source = LoadInfo(postId);
            if (source != null && results.Count > 0) SaveSuggestions(source, results);
            return results;
        }

        public void SaveSuggestions(PostInfo source, IEnumerable<MatchResult> results)
        {
            var now = DateTime.Now;
            foreach (var r in results)
            {
                int lostId = source.PostType == "Lost" ? source.Id : r.CandidatePostId;
                int foundId = source.PostType == "Lost" ? r.CandidatePostId : source.Id;
                int score = r.Score;

                var existing = db.MatchSuggestions.FirstOrDefault(m =>
                    m.LostPostId == lostId && m.FoundPostId == foundId && m.AlgorithmVersion == AlgorithmVersion);
                if (existing != null)
                {
                    existing.Score = score;
                    existing.CreatedAt = now;
                }
                else
                {
                    db.MatchSuggestions.Add(new MatchSuggestion
                    {
                        LostPostId = lostId, FoundPostId = foundId, Score = score,
                        AlgorithmVersion = AlgorithmVersion, CreatedAt = now
                    });
                }
            }
            try { db.SaveChanges(); }
            catch (DbUpdateException) { /* request khac vua luu cung cap -> bo qua, cache khong quan trong */ }
        }

        // ---------------------------------------------------------------
        // 2) Cham diem: ham THUAN (khong dung DB) -> de test rieng
        // ---------------------------------------------------------------
        public static MatchResult Score(PostInfo a, PostInfo b)
        {
            var reasons = new List<string>();
            double total = 0;

            // Danh muc (30)
            if (a.CategoryId == b.CategoryId) { total += 30; reasons.Add("Cùng danh mục (+30)"); }
            else reasons.Add("Khác danh mục (+0)");

            // Dia diem (25 / 12 / 0)
            if (a.LocationId == b.LocationId) { total += 25; reasons.Add("Cùng khu vực (+25)"); }
            else if (a.CampusId == b.CampusId) { total += 12; reasons.Add("Cùng cơ sở, khác khu vực (+12)"); }
            else reasons.Add("Khác cơ sở (+0)");

            // Thoi gian (20 / 10 / 0)
            double hours = Math.Abs((a.HappenedAt - b.HappenedAt).TotalHours);
            if (hours <= 24) { total += 20; reasons.Add("Cách nhau không quá 24 giờ (+20)"); }
            else if (hours <= 24 * 7) { total += 10; reasons.Add("Cách nhau trong 7 ngày (+10)"); }
            else reasons.Add("Cách nhau hơn 7 ngày (+0)");

            // Mau sac (10)
            string ca = NormalizeText(a.Color), cb = NormalizeText(b.Color);
            if (ca.Length == 0 || cb.Length == 0) reasons.Add("Thiếu thông tin màu sắc (+0)");
            else if (ca == cb) { total += 10; reasons.Add("Cùng màu sắc (+10)"); }
            else reasons.Add("Khác màu sắc (+0)");

            // Mo ta (15) = Jaccard cua tap tu khoa * 15
            var ta = Tokenize((a.Title ?? "") + " " + (a.PublicDescription ?? ""));
            var tb = Tokenize((b.Title ?? "") + " " + (b.PublicDescription ?? ""));
            if (ta.Count == 0 || tb.Count == 0)
            {
                reasons.Add("Thiếu mô tả để so sánh (+0)");
            }
            else
            {
                var shared = ta.Intersect(tb).ToList();
                int union = ta.Union(tb).Count();
                double pts = 15.0 * shared.Count / union;
                total += pts;
                if (shared.Count > 0)
                    reasons.Add("Từ khóa trùng: " + string.Join(", ", shared.Take(5)) + " (+" + Math.Round(pts, 1).ToString("0.#", CultureInfo.InvariantCulture) + ")");
                else
                    reasons.Add("Không có từ khóa trùng (+0)");
            }

            int score = (int)Math.Round(total, MidpointRounding.AwayFromZero);
            if (score < 0) score = 0;
            if (score > 100) score = 100;

            return new MatchResult
            {
                CandidatePostId = b.Id, Score = score, Reasons = reasons,
                HappenedAt = b.HappenedAt, AlgorithmVersion = AlgorithmVersion
            };
        }

        // ---------------------------------------------------------------
        // 3) Chuan hoa tieng Viet
        // ---------------------------------------------------------------
        private static readonly HashSet<string> StopWords = new HashSet<string>
        {
            "va", "cua", "la", "co", "toi", "minh", "duoc", "o", "tai", "mot", "cac", "cho", "nay",
            "khi", "voi", "de", "den", "trong", "ban", "nao", "nho", "giup", "hien", "dang"
        };

        /// <summary>Viet thuong, bo dau tieng Viet, bo ky tu la; "Trắng" va "trang" cung ra "trang".</summary>
        public static string NormalizeText(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "";
            string lower = input.Trim().ToLowerInvariant().Replace('đ', 'd');
            string decomposed = lower.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(decomposed.Length);
            foreach (char ch in decomposed)
            {
                var cat = CharUnicodeInfo.GetUnicodeCategory(ch);
                if (cat == UnicodeCategory.NonSpacingMark) continue;   // bo dau thanh
                sb.Append(char.IsLetterOrDigit(ch) ? ch : ' ');
            }
            return string.Join(" ", sb.ToString().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
        }

        public static HashSet<string> Tokenize(string input)
        {
            var set = new HashSet<string>();
            foreach (var t in NormalizeText(input).Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (t.Length >= 2 && !StopWords.Contains(t)) set.Add(t);
            }
            return set;
        }
    }
}
