namespace FindBack.Web.Services
{
    /// <summary>Ket qua tra ve tu Service: thanh cong / that bai kem thong bao.</summary>
    public class ServiceResult
    {
        public bool Ok { get; set; }
        public bool Forbidden { get; set; }   // true = khong co quyen (Controller tra 403)
        public bool NotFound { get; set; }    // true = khong tim thay (Controller tra 404)
        public string Message { get; set; }
        public int? Id { get; set; }

        public static ServiceResult Success(string message = null, int? id = null)
        {
            return new ServiceResult { Ok = true, Message = message, Id = id };
        }
        public static ServiceResult Fail(string message)
        {
            return new ServiceResult { Ok = false, Message = message };
        }
        public static ServiceResult Deny()
        {
            return new ServiceResult { Ok = false, Forbidden = true, Message = "Bạn không có quyền thực hiện thao tác này." };
        }
        public static ServiceResult Missing()
        {
            return new ServiceResult { Ok = false, NotFound = true, Message = "Không tìm thấy dữ liệu." };
        }
    }
}
