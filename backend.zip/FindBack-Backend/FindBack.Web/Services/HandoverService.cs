using System;
using System.Linq;

namespace FindBack.Web.Services
{
    /// <summary>
    /// Ban giao: hai ben (nguoi giu do + nguoi nhan) deu phai xac nhan moi Completed.
    /// Dung UPDATE co dieu kien trong transaction de 2 nguoi bam cung luc van chinh xac.
    /// </summary>
    public class HandoverService
    {
        private readonly FindBackEntities db;
        public HandoverService(FindBackEntities db) { this.db = db; }

        public ServiceResult Confirm(int handoverId, int userId)
        {
            using (var tx = db.Database.BeginTransaction())
            {
                var h = db.Handovers.AsNoTracking().FirstOrDefault(x => x.HandoverId == handoverId);
                if (h == null) return ServiceResult.Missing();
                var claim = db.Claims.AsNoTracking().First(c => c.ClaimId == h.ClaimId);
                var found = db.Posts.AsNoTracking().First(p => p.PostId == claim.FoundPostId);

                bool isFinder = found.AuthorUserId == userId;
                bool isClaimant = claim.ClaimantUserId == userId;
                if (!isFinder && !isClaimant) return ServiceResult.Deny();
                if (h.Status != "Pending") return ServiceResult.Fail("Lần trao trả này không còn chờ xác nhận.");

                var now = DateTime.Now;
                // UPDATE nguyen tu: chi ghi neu ben nay chua xac nhan va ban giao con Pending
                int affected = isFinder
                    ? db.Database.ExecuteSqlCommand(
                        "UPDATE Handovers SET FinderConfirmedAt = {0} WHERE HandoverId = {1} AND Status = 'Pending' AND FinderConfirmedAt IS NULL",
                        now, handoverId)
                    : db.Database.ExecuteSqlCommand(
                        "UPDATE Handovers SET ClaimantConfirmedAt = {0} WHERE HandoverId = {1} AND Status = 'Pending' AND ClaimantConfirmedAt IS NULL",
                        now, handoverId);
                if (affected == 0) return ServiceResult.Fail("Bạn đã xác nhận rồi hoặc lần trao trả đã thay đổi trạng thái.");

                // Doc lai du lieu MOI NHAT sau khi UPDATE
                var fresh = db.Handovers.First(x => x.HandoverId == handoverId);
                if (fresh.FinderConfirmedAt.HasValue && fresh.ClaimantConfirmedAt.HasValue)
                {
                    fresh.Status = "Completed";
                    fresh.CompletedAt = now;

                    var foundPost = db.Posts.First(p => p.PostId == found.PostId);
                    foundPost.Status = "Resolved";

                    // Tin Lost lien ket (cua nguoi nhan) cung duoc danh dau da xong
                    if (claim.RelatedLostPostId.HasValue)
                    {
                        int lostId = claim.RelatedLostPostId.Value;
                        int claimantId = claim.ClaimantUserId;
                        var lost = db.Posts.FirstOrDefault(p => p.PostId == lostId && p.PostType == "Lost"
                                                                && p.AuthorUserId == claimantId && p.Status == "Open");
                        if (lost != null) lost.Status = "Resolved";
                    }

                    // Cac claim Pending khac cho cung tin Found -> tu dong tu choi
                    int foundId = found.PostId;
                    var others = db.Claims.Where(c => c.FoundPostId == foundId && c.Status == "Pending").ToList();
                    foreach (var c in others) { c.Status = "Rejected"; c.ReviewedAt = now; }

                    db.SaveChanges();
                    tx.Commit();
                    return ServiceResult.Success("Hai bên đã xác nhận. Trao trả hoàn tất!");
                }

                tx.Commit();
                return ServiceResult.Success("Đã ghi nhận xác nhận của bạn. Chờ bên còn lại xác nhận.");
            }
        }

        public ServiceResult Dispute(int handoverId, int userId)
        {
            using (var tx = db.Database.BeginTransaction())
            {
                var h = db.Handovers.AsNoTracking().FirstOrDefault(x => x.HandoverId == handoverId);
                if (h == null) return ServiceResult.Missing();
                var claim = db.Claims.AsNoTracking().First(c => c.ClaimId == h.ClaimId);
                var found = db.Posts.AsNoTracking().First(p => p.PostId == claim.FoundPostId);

                if (found.AuthorUserId != userId && claim.ClaimantUserId != userId) return ServiceResult.Deny();

                int affected = db.Database.ExecuteSqlCommand(
                    "UPDATE Handovers SET Status = 'Disputed' WHERE HandoverId = {0} AND Status = 'Pending'", handoverId);
                if (affected == 0) return ServiceResult.Fail("Không thể báo tranh chấp ở trạng thái hiện tại.");

                tx.Commit();
                return ServiceResult.Success("Đã báo tranh chấp. Việc xác nhận bàn giao được tạm dừng.");
            }
        }
    }
}
