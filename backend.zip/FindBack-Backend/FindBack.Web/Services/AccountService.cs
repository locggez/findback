using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Services
{
    public class AuthResult
    {
        public bool Succeeded { get; set; }
        public int UserId { get; set; }
        public string Role { get; set; }
        public string Error { get; set; }
    }

    /// <summary>Dang ky, dang nhap (kiem tra mat khau), cap nhat ho so.</summary>
    public class AccountService
    {
        private readonly FindBackEntities db;
        public AccountService(FindBackEntities db) { this.db = db; }

        // Hash gia, dung de tinh thoi gian khi email khong ton tai (giam do lo thong tin)
        private static readonly string DummyHash = PasswordHasher.Hash("dummy-password-for-timing");

        public static string NormalizeEmail(string email)
        {
            return (email ?? "").Trim().ToLowerInvariant();
        }

        public AuthResult Register(RegisterVm vm)
        {
            string email = NormalizeEmail(vm.Email);
            if (db.Users.Any(u => u.Email == email))
                return new AuthResult { Error = "Email này đã được đăng ký." };

            var role = db.Roles.FirstOrDefault(r => r.Name == "Student");
            if (role == null) return new AuthResult { Error = "Chưa có dữ liệu vai trò. Hãy chạy 02_seed_reference.sql." };

            var user = new FindBack.Web.User
            {
                RoleId = role.RoleId,
                DisplayName = vm.DisplayName.Trim(),
                Email = email,
                PasswordHash = PasswordHasher.Hash(vm.Password),
                IsActive = true,
                CreatedAt = DateTime.Now
            };
            db.Users.Add(user);
            try { db.SaveChanges(); }
            catch (DbUpdateException) { return new AuthResult { Error = "Email này đã được đăng ký." }; }

            return new AuthResult { Succeeded = true, UserId = user.UserId, Role = role.Name };
        }

        public AuthResult Authenticate(string emailInput, string password)
        {
            const string generic = "Email hoặc mật khẩu không đúng.";
            string email = NormalizeEmail(emailInput);
            var user = db.Users.FirstOrDefault(u => u.Email == email);

            if (user == null)
            {
                PasswordHasher.Verify(password, DummyHash);
                return new AuthResult { Error = generic };
            }
            if (!PasswordHasher.Verify(password, user.PasswordHash)) return new AuthResult { Error = generic };
            if (!user.IsActive) return new AuthResult { Error = "Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên." };

            int roleId = user.RoleId;
            string roleName = db.Roles.Where(r => r.RoleId == roleId).Select(r => r.Name).First();
            return new AuthResult { Succeeded = true, UserId = user.UserId, Role = roleName };
        }

        public ProfileVm GetProfile(int userId)
        {
            return db.Users.Where(u => u.UserId == userId)
                .Select(u => new ProfileVm { DisplayName = u.DisplayName, Email = u.Email }).FirstOrDefault();
        }

        public ServiceResult UpdateProfile(int userId, string displayName)
        {
            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null) return ServiceResult.Missing();
            user.DisplayName = displayName.Trim();
            db.SaveChanges();
            return ServiceResult.Success("Đã cập nhật hồ sơ.");
        }
    }
}
