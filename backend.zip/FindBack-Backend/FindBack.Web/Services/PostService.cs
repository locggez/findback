using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using FindBack.Web.ViewModels;

namespace FindBack.Web.Services
{
    /// <summary>Nghiep vu tin dang: tim kiem, xem chi tiet, tao, sua, dong tin.</summary>
    public class PostService
    {
        public const int PageSize = 9;
        public const int MaxPostsPerDay = 10;

        private readonly FindBackEntities db;
        public PostService(FindBackEntities db) { this.db = db; }

        // Dong du lieu phang (join 5 bang) dung chung cho nhieu truy van
        private class PostRow
        {
            public int Id { get; set; }
            public int AuthorUserId { get; set; }
            public string AuthorName { get; set; }
            public string Title { get; set; }
            public string PublicDescription { get; set; }
            public string Color { get; set; }
            public string PostType { get; set; }
            public string Status { get; set; }
            public int CategoryId { get; set; }
            public string CategoryName { get; set; }
            public int LocationId { get; set; }
            public string LocationName { get; set; }
            public int CampusId { get; set; }
            public string CampusName { get; set; }
            public DateTime HappenedAt { get; set; }
            public DateTime CreatedAt { get; set; }
        }

        private IQueryable<PostRow> Rows()
        {
            return from p in db.Posts
                   join c in db.Categories on p.CategoryId equals c.CategoryId
                   join l in db.Locations on p.LocationId equals l.LocationId
                   join ca in db.Campuses on l.CampusId equals ca.CampusId
                   join u in db.Users on p.AuthorUserId equals u.UserId
                   where !p.IsDeleted
                   select new PostRow
                   {
                       Id = p.PostId, AuthorUserId = p.AuthorUserId, AuthorName = u.DisplayName,
                       Title = p.Title, PublicDescription = p.PublicDescription, Color = p.Color,
                       PostType = p.PostType, Status = p.Status,
                       CategoryId = c.CategoryId, CategoryName = c.Name,
                       LocationId = l.LocationId, LocationName = l.Name,
                       CampusId = ca.CampusId, CampusName = ca.Name,
                       HappenedAt = p.HappenedAt, CreatedAt = p.CreatedAt
                   };
        }

        private static PostCardVm ToCard(PostRow r)
        {
            return new PostCardVm
            {
                Id = r.Id, Title = r.Title, PostType = r.PostType, CategoryName = r.CategoryName,
                CampusName = r.CampusName, LocationName = r.LocationName,
                HappenedAt = r.HappenedAt, Status = r.Status
            };
        }

        // ---------------- Tim kiem + phan trang ----------------
        public PostsIndexVm Search(string query, string type, int? categoryId, int? campusId, int page)
        {
            var q = Rows().Where(r => r.Status != "Cancelled");   // tin da dong khong hien cong khai

            if (type == "Lost" || type == "Found") q = q.Where(r => r.PostType == type);
            if (categoryId.HasValue) { int cid = categoryId.Value; q = q.Where(r => r.CategoryId == cid); }
            if (campusId.HasValue) { int caid = campusId.Value; q = q.Where(r => r.CampusId == caid); }
            if (!string.IsNullOrWhiteSpace(query))
            {
                string k = query.Trim();
                q = q.Where(r => r.Title.Contains(k) || r.PublicDescription.Contains(k)
                                 || r.Color.Contains(k) || r.CategoryName.Contains(k));
            }

            int total = q.Count();
            int pageCount = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
            if (page < 1) page = 1;
            if (page > pageCount) page = pageCount;

            var rows = q.OrderByDescending(r => r.CreatedAt).ThenByDescending(r => r.Id)
                        .Skip((page - 1) * PageSize).Take(PageSize).ToList();

            return new PostsIndexVm
            {
                Query = query, Type = type, CategoryId = categoryId, CampusId = campusId,
                Posts = rows.Select(ToCard).ToList(),
                Categories = CategoryItems(), Campuses = CampusItems(),
                Page = page, PageCount = pageCount
            };
        }

        // ---------------- Chi tiet ----------------
        public PostDetailsVm GetDetails(int id, int? userId, bool isAdmin)
        {
            var r = Rows().FirstOrDefault(x => x.Id == id);
            if (r == null) return null;

            bool isOwner = userId.HasValue && r.AuthorUserId == userId.Value;
            // Tin da dong: chi chu tin / admin moi xem duoc
            if (r.Status == "Cancelled" && !isOwner && !isAdmin) return null;

            return new PostDetailsVm
            {
                Id = r.Id, Title = r.Title, PostType = r.PostType, CategoryName = r.CategoryName,
                CampusName = r.CampusName, LocationName = r.LocationName, HappenedAt = r.HappenedAt,
                Status = r.Status, PublicDescription = r.PublicDescription,
                Color = string.IsNullOrWhiteSpace(r.Color) ? null : r.Color,
                AuthorDisplayName = r.AuthorName,
                CanEdit = (isOwner || isAdmin) && r.Status == "Open",
                CanClaim = userId.HasValue && !isOwner && r.PostType == "Found" && r.Status == "Open",
                CanSeeMatches = isOwner || isAdmin
            };
        }

        public IList<PostCardVm> GetMine(int userId)
        {
            return Rows().Where(r => r.AuthorUserId == userId)
                         .OrderByDescending(r => r.CreatedAt).ToList().Select(ToCard).ToList();
        }

        public IList<PostCardVm> GetRecent(int count)
        {
            return Rows().OrderByDescending(r => r.CreatedAt).Take(count).ToList().Select(ToCard).ToList();
        }

        public Dictionary<int, PostCardVm> GetCards(IEnumerable<int> ids)
        {
            var idList = ids.Distinct().ToList();
            return Rows().Where(r => idList.Contains(r.Id)).ToList().Select(ToCard).ToDictionary(c => c.Id);
        }

        // ---------------- Danh sach chon (dropdown) ----------------
        public IEnumerable<SelectListItem> CategoryItems()
        {
            return db.Categories.Where(c => c.IsActive).OrderBy(c => c.Name).ToList()
                     .Select(c => new SelectListItem { Value = c.CategoryId.ToString(), Text = c.Name }).ToList();
        }

        public IEnumerable<SelectListItem> CampusItems()
        {
            return db.Campuses.Where(c => c.IsActive).OrderBy(c => c.Name).ToList()
                     .Select(c => new SelectListItem { Value = c.CampusId.ToString(), Text = c.Name }).ToList();
        }

        public void FillLookups(PostFormVm vm)
        {
            vm.Categories = CategoryItems();
            vm.Campuses = CampusItems();
            vm.LocationOptions = db.Locations.Where(l => l.IsActive).OrderBy(l => l.Name).ToList()
                .Select(l => new LocationOptionVm { Id = l.LocationId, Name = l.Name, CampusId = l.CampusId }).ToList();
            vm.Locations = vm.LocationOptions
                .Where(l => vm.CampusId.HasValue && l.CampusId == vm.CampusId.Value)
                .Select(l => new SelectListItem { Value = l.Id.ToString(), Text = l.Name }).ToList();
        }

        // ---------------- Kiem tra nghiep vu (ngoai DataAnnotations) ----------------
        /// <summary>Tra ve danh sach loi theo ten truong. Rong = hop le.</summary>
        public Dictionary<string, string> ValidateForm(PostFormVm vm)
        {
            var errors = new Dictionary<string, string>();
            if (vm.CategoryId.HasValue)
            {
                int cid = vm.CategoryId.Value;
                if (!db.Categories.Any(c => c.CategoryId == cid && c.IsActive))
                    errors["CategoryId"] = "Danh mục không hợp lệ.";
            }
            if (vm.LocationId.HasValue && vm.CampusId.HasValue)
            {
                int lid = vm.LocationId.Value, caid = vm.CampusId.Value;
                // Quan he Co so <-> Khu vuc phai dung (khong tin du lieu tu trinh duyet)
                bool ok = (from l in db.Locations
                           join c in db.Campuses on l.CampusId equals c.CampusId
                           where l.LocationId == lid && l.CampusId == caid && l.IsActive && c.IsActive
                           select l.LocationId).Any();
                if (!ok) errors["LocationId"] = "Khu vực không thuộc cơ sở đã chọn.";
            }
            if (vm.HappenedAt.HasValue && vm.HappenedAt.Value > DateTime.Now.AddMinutes(5))
                errors["HappenedAt"] = "Thời gian không được ở tương lai.";
            return errors;
        }

        // ---------------- Tao / sua / dong ----------------
        public ServiceResult Create(PostFormVm vm, int userId)
        {
            var since = DateTime.Now.AddDays(-1);
            int today = db.Posts.Count(p => p.AuthorUserId == userId && p.CreatedAt >= since);
            if (today >= MaxPostsPerDay)
                return ServiceResult.Fail("Bạn đã đăng quá " + MaxPostsPerDay + " tin trong 24 giờ. Vui lòng thử lại sau.");

            var post = new Post
            {
                AuthorUserId = userId,
                CategoryId = vm.CategoryId.Value,
                LocationId = vm.LocationId.Value,
                PostType = vm.PostType,
                Title = vm.Title.Trim(),
                PublicDescription = vm.PublicDescription.Trim(),
                Color = string.IsNullOrWhiteSpace(vm.Color) ? null : vm.Color.Trim(),
                HappenedAt = vm.HappenedAt.Value,
                CreatedAt = DateTime.Now,
                Status = "Open",
                IsDeleted = false
            };
            db.Posts.Add(post);
            db.SaveChanges();
            return ServiceResult.Success("Đã đăng tin.", post.PostId);
        }

        public PostFormVm BuildEditVm(int postId)
        {
            var r = Rows().FirstOrDefault(x => x.Id == postId);
            if (r == null) return null;
            var vm = new PostFormVm
            {
                Id = r.Id, PostType = r.PostType, Title = r.Title, CategoryId = r.CategoryId,
                CampusId = r.CampusId, LocationId = r.LocationId, HappenedAt = r.HappenedAt,
                Color = r.Color, PublicDescription = r.PublicDescription
            };
            FillLookups(vm);
            return vm;
        }

        public ServiceResult Update(PostFormVm vm, int userId, bool isAdmin)
        {
            if (!vm.Id.HasValue) return ServiceResult.Missing();
            int id = vm.Id.Value;
            var post = db.Posts.FirstOrDefault(p => p.PostId == id && !p.IsDeleted);
            if (post == null) return ServiceResult.Missing();
            if (post.AuthorUserId != userId && !isAdmin) return ServiceResult.Deny();     // chu tin / admin
            if (post.Status != "Open") return ServiceResult.Fail("Chỉ sửa được tin đang mở.");
            if (vm.PostType != post.PostType) return ServiceResult.Fail("Không thể đổi loại tin (Báo mất / Nhặt được).");

            post.CategoryId = vm.CategoryId.Value;
            post.LocationId = vm.LocationId.Value;
            post.Title = vm.Title.Trim();
            post.PublicDescription = vm.PublicDescription.Trim();
            post.Color = string.IsNullOrWhiteSpace(vm.Color) ? null : vm.Color.Trim();
            post.HappenedAt = vm.HappenedAt.Value;
            db.SaveChanges();
            return ServiceResult.Success("Đã cập nhật tin.", post.PostId);
        }

        /// <summary>Dong tin (Open -> Cancelled). Khong xoa cung de giu lich su.</summary>
        public ServiceResult Close(int postId, int userId, bool isAdmin)
        {
            using (var tx = db.Database.BeginTransaction())
            {
                var post = db.Posts.FirstOrDefault(p => p.PostId == postId && !p.IsDeleted);
                if (post == null) return ServiceResult.Missing();
                if (post.AuthorUserId != userId && !isAdmin) return ServiceResult.Deny();
                if (post.Status != "Open") return ServiceResult.Fail("Tin này không còn ở trạng thái mở.");

                if (post.PostType == "Found")
                {
                    // Dang ban giao do dang -> khong cho dong
                    bool handoverActive = (from c in db.Claims
                                           join h in db.Handovers on c.ClaimId equals h.ClaimId
                                           where c.FoundPostId == postId && (h.Status == "Pending" || h.Status == "Disputed")
                                           select h.HandoverId).Any();
                    if (handoverActive)
                        return ServiceResult.Fail("Tin đang trong quá trình bàn giao, chưa thể đóng.");

                    var pending = db.Claims.Where(c => c.FoundPostId == postId && c.Status == "Pending").ToList();
                    foreach (var c in pending) { c.Status = "Rejected"; c.ReviewedAt = DateTime.Now; }
                }

                post.Status = "Cancelled";
                db.SaveChanges();
                tx.Commit();
                return ServiceResult.Success("Đã đóng tin.", postId);
            }
        }
    }
}
