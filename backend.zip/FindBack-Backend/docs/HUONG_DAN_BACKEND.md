# HUFLIT FindBack — Hướng dẫn Backend cho người mới

> Tài liệu này đi kèm bộ mã nguồn backend **ASP.NET MVC 5 + Entity Framework 6 (Database First) + SQL Server**, đúng stack mà nhóm đã đề xuất trong `docs/06_MVC_ARCHITECTURE.md`.
> Đọc theo thứ tự từ trên xuống. Làm xong Phần 1–6 là website chạy được.

---

## 0. Backend là gì? (đọc 2 phút)

Hãy tưởng tượng một **nhà hàng**:

| Nhà hàng | Website FindBack | Nằm ở đâu |
|---|---|---|
| Thực đơn, bàn ăn (khách nhìn thấy) | **View** — giao diện HTML (Razor `.cshtml`) | `Views/` |
| Nhân viên phục vụ (nhận order, kiểm tra khách có quyền gọi món không) | **Controller** — nhận request, kiểm tra đăng nhập/quyền | `Controllers/` |
| Bếp (nấu ăn theo công thức) | **Service** — luật nghiệp vụ: chấm điểm gợi ý, duyệt claim, bàn giao | `Services/` |
| Kho nguyên liệu | **SQL Server** — lưu dữ liệu thật | `database/` |
| Phiếu order | **ViewModel** — hộp dữ liệu đi giữa View và Controller | `ViewModels/` |

**Một request đi như thế nào?** Ví dụ bấm "Đăng tin":

```
Trình duyệt ──POST /Posts/Create──▶ PostsController.Create
                                      │ 1. Có đăng nhập không? ([Authorize])
                                      │ 2. Form hợp lệ không? (ModelState + ValidateForm)
                                      ▼
                                   PostService.Create ──LINQ/EF──▶ SQL Server (bảng Posts)
                                      │
Trình duyệt ◀── chuyển hướng /Posts/Details/7 ◀── MatchService tính & lưu gợi ý (bảng MatchSuggestions)
```

**Nguyên tắc vàng:** *mọi kiểm tra quyền phải làm ở server*. Trình duyệt có thể bị sửa tay (ví dụ đổi `id` trên URL), nên Controller **không bao giờ tin** `UserId` do form gửi lên — luôn lấy từ phiên đăng nhập.

---

## 1. Chuẩn bị máy (làm 1 lần)

Bạn cần **Windows** (ASP.NET MVC 5 chạy trên .NET Framework — không chạy trên macOS/Linux).

1. Cài **Visual Studio 2022 Community** (miễn phí). Khi cài, tick 2 workload:
   - **ASP.NET and web development**
   - **Data storage and processing** (có sẵn SQL Server LocalDB — bản SQL Server mini chạy trên máy bạn, không cần cài thêm gì).
2. Mở Visual Studio lần đầu, đăng nhập (hoặc "Skip").

> Muốn dùng SQL Server Express + SSMS thay LocalDB cũng được; chỉ cần đổi tên server ở Bước 2 và 3.

---

## 2. Bước 1 — Tạo database

1. Mở Visual Studio → menu **View → SQL Server Object Explorer**.
2. Mở thư mục `database/` của bộ mã nguồn này. Bạn có 4 file:

| File | Việc | Bắt buộc? |
|---|---|---|
| `01_schema.sql` | Tạo database `FindBackDb` + 9 bảng + ràng buộc + index | **Có** |
| `02_seed_reference.sql` | Vai trò (Student/Admin), 4 cơ sở, khu vực, 9 danh mục | **Có** |
| `03_demo_data.sql` | 3 tài khoản demo + 6 tin mẫu | Tuỳ chọn (nên chạy để có dữ liệu thử) |
| `04_make_admin.sql` | Nâng 1 tài khoản đã đăng ký lên Admin | Khi cần |

3. Chạy lần lượt: trong Visual Studio chọn **File → Open → File…** → mở `01_schema.sql` → bấm chuột phải trong cửa sổ code → **Execute** (hoặc `Ctrl+Shift+E`) → khi hỏi kết nối: Server name = `(localdb)\MSSQLLocalDB`, Authentication = Windows → **Connect**. Làm tương tự với `02_...` rồi `03_...`.
4. Kiểm tra: trong SQL Server Object Explorer → `(localdb)\MSSQLLocalDB` → Databases → **FindBackDb** → Tables → phải thấy **9 bảng**: `Roles, Users, Campuses, Locations, Categories, Posts, MatchSuggestions, Claims, Handovers`.

> ⚠ `01_schema.sql` **xoá và tạo lại** các bảng — chạy lại sẽ mất dữ liệu đã nhập.
> ⚠ Tài khoản trong `03_demo_data.sql` có mật khẩu công khai `Demo@12345` — **chỉ dùng trên máy local**, không dùng khi triển khai thật.

**Vì sao thiết kế SQL trước?** Đây là *Database First*: bạn thiết kế bảng bằng SQL (khoá chính, khoá ngoại, CHECK, UNIQUE, index), sau đó EF **đọc** database và tự sinh class C#. Ví dụ ràng buộc quan trọng trong schema:
- `UX_Claims_OneApprovedPerFound`: mỗi tin Found chỉ có **một** claim được Approved — ngay cả khi 2 người bấm cùng lúc, database vẫn chặn.
- `CK_Handovers_Completed`: bàn giao chỉ `Completed` khi **cả hai bên** đã xác nhận.

---

## 3. Bước 2 — Tạo project ASP.NET MVC 5

1. Visual Studio → **Create a new project** → chọn **ASP.NET Web Application (.NET Framework)** (ngôn ngữ C#) → Next.
2. **Project name:** `FindBack.Web` · **Solution name:** `FindBack` · **Framework: .NET Framework 4.8** → Create.
3. Chọn template **MVC**. Mục **Authentication** bấm *Change* → chọn **No Authentication**. (Ta tự làm đăng nhập với bảng `Users`.) → Create.
4. Kiểm tra namespace: chuột phải project → **Properties → Application → Default namespace** phải là `FindBack.Web`. Nếu khác, sửa lại.
5. Bấm **F5** thử: thấy trang mẫu của template là OK. Tắt trình duyệt (Shift+F5).

---

## 4. Bước 3 — EF Database First (để EF đọc database)

1. Chuột phải project `FindBack.Web` → **Add → New Item… → Data → ADO.NET Entity Data Model**.
2. **Name:** `FindBackModel` → Add.
3. Chọn **EF Designer from database** → Next.
4. **New Connection…** → Data source: *Microsoft SQL Server* → Server name `(localdb)\MSSQLLocalDB` → chọn database **FindBackDb** → OK.
5. Mục *"Save connection settings in Web.config as"* phải đúng là **`FindBackEntities`** → Next.
6. Chọn **Entity Framework 6.x** → Next (VS tự cài NuGet `EntityFramework`).
7. Tick **Tables** (chọn cả 9 bảng). Giữ nguyên 2 ô: ✅ *Pluralize or singularize generated object names* và ✅ *Include foreign key columns* → Finish. Có hộp thoại cảnh báo bảo mật → OK.
8. **Build** (Ctrl+Shift+B). Mở `FindBackModel.edmx` sẽ thấy sơ đồ 9 bảng và đường nối quan hệ — đây chính là ERD để bạn trình bày khi bảo vệ.

**Kiểm tra EF sinh đúng tên** (code backend phụ thuộc các tên này). Mở `FindBackModel.Context.cs`, phải có:
- class `FindBackEntities` trong namespace `FindBack.Web`
- `DbSet<Role> Roles`, `DbSet<User> Users`, `DbSet<Campus> Campuses`, `DbSet<Location> Locations`, `DbSet<Category> Categories`, `DbSet<Post> Posts`, `DbSet<MatchSuggestion> MatchSuggestions`, `DbSet<Claim> Claims`, `DbSet<Handover> Handovers`

---

## 5. Bước 4 — Chép mã backend vào project

1. Đóng Visual Studio hoặc để mở đều được. Dùng File Explorer, mở thư mục `FindBack.Web/` của bộ mã nguồn này, **copy toàn bộ nội dung** và dán vào thư mục project `FindBack.Web` (chỗ có file `FindBack.Web.csproj`). Khi hỏi ghi đè → **Replace**. File bị thay: `Global.asax.cs`, `HomeController.cs`, `_Layout.cshtml`, `Home/Index.cshtml`.
2. Quay lại Visual Studio → Solution Explorer → bấm biểu tượng **Show All Files** (hình tờ giấy có viền chấm) → với mỗi thư mục/file mới (chữ mờ): chuột phải → **Include In Project**.
   - ⚠ **Bước này rất quan trọng với file `.cs`**: file chưa "Include" sẽ **không được biên dịch**, bạn sẽ gặp lỗi "controller not found".
3. Cấu trúc mong đợi:

```
FindBack.Web
├─ Controllers/   Account, Admin, Base, Claims, Handovers, Home, Matches, Posts
├─ Services/      AccountService, ClaimService, HandoverService, MatchService,
│                 PasswordHasher, PostService, ServiceResult
├─ ViewModels/    ViewModels.cs
├─ Views/         Account, Admin, Claims, Home, Matches, Posts, Shared (17 file .cshtml)
├─ Content/findback.css      Scripts/findback-ui.js
└─ Global.asax.cs
```

4. Mở **Web.config gốc** (cạnh `Global.asax`, **không phải** `Views/Web.config`) và làm theo `Web.config.snippet.xml`: thêm khối `<authentication mode="Forms">` trong `<system.web>`. Xác nhận trong `<connectionStrings>` có `FindBackEntities`.
5. **Build** lại. Nếu có lỗi, xem Phần 9.

---

## 6. Bước 5 — Chạy và dùng thử

Bấm **F5**. Trình duyệt mở `https://localhost:xxxxx/`.

**Tài khoản demo** (nếu đã chạy `03_demo_data.sql`; mật khẩu chung `Demo@12345`):

| Email | Vai trò |
|---|---|
| `student.a@findback.local` | Sinh viên A (đang mất tai nghe, dây sạc) |
| `student.b@findback.local` | Sinh viên B (đã nhặt tai nghe, dây sạc) |
| `admin.demo@findback.local` | Admin |

**Kịch bản thử end-to-end** (dùng 2 trình duyệt, hoặc 1 thường + 1 ẩn danh, để đăng nhập A và B cùng lúc):

1. **A** đăng nhập → *Tin của tôi* → mở "Mất tai nghe Bluetooth màu trắng" → **Xem tin tương đồng** → thấy tin của B ở đầu danh sách, điểm khoảng **88** kèm các lý do (cùng danh mục, cùng khu vực, ≤ 24 giờ, cùng màu, từ khoá trùng).
2. **A** mở tin của B → **Gửi yêu cầu nhận** → nhập đặc điểm riêng (ví dụ "có vết xước ở hộp sạc, ốp tai bên trái hơi lỏng") → gửi.
3. **B** đăng nhập → *Yêu cầu nhận* → cột **"Yêu cầu gửi đến"** thấy đặc điểm riêng của A → **Chấp nhận**.
4. **A** bấm **Xác nhận giao/nhận** → thanh trạng thái hiện "Người nhận: đã xác nhận · Người giữ: chưa xác nhận".
5. **B** bấm **Xác nhận giao/nhận** → bàn giao **Hoàn tất**; cả hai tin chuyển "Đã trao trả".
6. Đăng nhập **Admin** → menu *Quản trị*: thêm/ngưng danh mục, khoá/mở khoá tài khoản.

Tự tạo tài khoản thật: *Đăng nhập → Đăng ký*. Muốn nâng lên Admin: sửa email trong `04_make_admin.sql` rồi chạy.

---

## 7. Mỗi phần backend làm gì (để bạn giải thích khi bảo vệ)

| Thành phần | Làm gì | Ý chính cần nhớ |
|---|---|---|
| `PasswordHasher` | Băm mật khẩu PBKDF2-SHA256 + salt ngẫu nhiên, 100.000 vòng | DB **không bao giờ** lưu mật khẩu thật; so sánh thời gian cố định |
| `Global.asax.cs` | Đọc cookie đăng nhập mỗi request → dựng `User` kèm vai trò | Nhờ đó `[Authorize(Roles="Admin")]` hoạt động |
| `BaseController` | Mở/đóng kết nối DB, lấy `CurrentUserId`, chặn tài khoản bị khoá | `UserId` lấy từ cookie đã mã hoá, **không** từ form |
| `PostService` | Tìm kiếm/phân trang bằng LINQ, tạo/sửa/đóng tin | Kiểm tra cơ sở ↔ khu vực ở server; giới hạn 10 tin/24h |
| `MatchService` | Chấm điểm `rule-v1`: danh mục 30 + địa điểm 25 + thời gian 20 + màu 10 + mô tả 15 | **Thuật toán luật, không phải AI đã train.** Hàm `Score()` thuần, dễ test; lưu cache vào `MatchSuggestions` |
| `ClaimService` | Gửi/duyệt/rút claim; chặn tự claim tin của mình, claim trùng | Duyệt trong **transaction** + unique index chặn 2 người cùng được Approve |
| `HandoverService` | Xác nhận 2 phía, báo tranh chấp | Dùng `UPDATE … WHERE … IS NULL` nguyên tử để 2 người bấm cùng lúc vẫn đúng |
| `AdminController` | Thêm/ngưng danh mục, khoá tài khoản | Không xoá cứng vì bài đăng đang tham chiếu |

**Bảo mật đã làm:** mọi POST có `ValidateAntiForgeryToken` · đăng xuất bằng POST · cookie `HttpOnly` · ownership kiểm tra trong từng action · `PrivateProof` chỉ trả cho người giữ đồ · output Razor tự mã hoá chống XSS · login báo lỗi chung (không lộ email có tồn tại) · giới hạn tần suất đăng tin/claim.

**Vì sao `Score` nâng ngưỡng lên 50?** Tài liệu gợi ý 40. Khi thử các mẫu trong `docs/07`, cặp *sai* (khác cơ sở cách vài tháng: 46 điểm; ví vs tai nghe cùng chỗ: 45) vẫn lọt qua 40, còn cặp *đúng* đạt 87–91. Ngưỡng 50 tách được hai nhóm — nhưng đây chỉ là thử trên ít mẫu; hãy test thêm và đổi hằng số `MinimumScore` nếu cần, rồi ghi vào `14_DECISIONS_AND_OPEN_ITEMS.md`.

---

## 8. Checklist kiểm thử bảo mật (theo `docs/08`)

Thử và ghi kết quả thật vào báo cáo:

- [ ] Đăng nhập A, mở `/Posts/Edit/{id tin của B}` → **403**.
- [ ] A mở `/Matches/ForPost/{id tin của B}` → **403**.
- [ ] Chưa đăng nhập, mở `/Posts/Create` → chuyển về trang đăng nhập.
- [ ] Student mở `/Admin` → bị chặn.
- [ ] A gửi claim cho tin Found do chính A đăng → báo lỗi.
- [ ] A gửi claim 2 lần cho cùng 1 tin → báo lỗi.
- [ ] Gửi form thiếu tiêu đề / khu vực không thuộc cơ sở → không tạo bản ghi.
- [ ] B chấp nhận claim của A rồi C gửi claim cho cùng tin → bị chặn.
- [ ] Chỉ 1 bên xác nhận → trạng thái **chưa** `Completed`.
- [ ] Admin khoá một tài khoản → tài khoản đó bị đăng xuất ở lần truy cập sau.
- [ ] Kiểm tra DB: cột `PasswordHash` là chuỗi `v1.100000....`, không phải mật khẩu thật.

---

## 9. Lỗi thường gặp

| Triệu chứng | Nguyên nhân & cách sửa |
|---|---|
| `The type or namespace name 'FindBackEntities' could not be found` | Chưa làm Bước 3, hoặc namespace của EDMX khác `FindBack.Web`. Kiểm tra *Default namespace* của project và tên connection `FindBackEntities`. |
| `'Campuse' / 'Categorie'…` hoặc tên entity lạ | EF đặt tên sai do tắt/bật pluralize. Xoá EDMX, làm lại Bước 3, **giữ tick** *Pluralize or singularize*. |
| `The resource cannot be found` / controller không tìm thấy | File `.cs`/`.cshtml` chưa **Include In Project** (Bước 4.2). |
| `Rfc2898DeriveBytes … HashAlgorithmName` không tồn tại | Project nhắm .NET < 4.7.2. Properties → Application → Target framework → **.NET Framework 4.8**. |
| `A claim of type 'NameIdentifier'… was not present` | `Global.asax.cs` chưa được thay bằng bản trong bộ mã (dòng `AntiForgeryConfig.UniqueClaimTypeIdentifier`). |
| Đăng nhập xong vẫn như chưa đăng nhập | Chưa thêm `<authentication mode="Forms">` vào Web.config gốc, hoặc trong Web.config còn dòng `mode="None"`. |
| `Cannot open database "FindBackDb"` / không kết nối được | Mở Command Prompt chạy `sqllocaldb start MSSQLLocalDB`; kiểm tra đã chạy `01_schema.sql`. |
| `INSERT failed because the following SET options have incorrect settings: QUOTED_IDENTIFIER` | Chạy script trong Visual Studio/SSMS (không dùng `sqlcmd` thiếu `-I`). |
| Đăng nhập demo báo sai mật khẩu | Chưa chạy `03_demo_data.sql`, hoặc gõ sai (`Demo@12345`, phân biệt hoa thường). |
| Sau khi sửa bảng SQL, code báo thiếu cột | EDMX không tự cập nhật: chuột phải vùng trống trong `FindBackModel.edmx` → **Update Model from Database…** → Refresh. |
| Trang trắng khi bị 403 | Đây là hành vi mong đợi khi truy cập trái quyền (trang lỗi đẹp là phần mở rộng). |

---

## 10. Giới hạn hiện tại — nói thẳng

- **Mã backend chưa được biên dịch/chạy trên máy thật khi tạo:** môi trường tạo ra nó không có .NET/SQL Server. Đã kiểm tra: cú pháp C# của 17 file bằng parser, cú pháp T-SQL của 4 script, khớp tên giữa 17 view ↔ ViewModel ↔ action, và thuật toán matching bằng bản port Python. **Lỗi biên dịch nhỏ (thiếu `using`, lệch tên EF) vẫn có thể xuất hiện lần đầu build** — hãy dùng bảng ở Phần 9; nếu còn lỗi, gửi nguyên văn thông báo để sửa.
- **Không có ảnh upload** (đúng phạm vi P0; ảnh chỉ xem trước ở trình duyệt).
- **Không phải AI đã huấn luyện:** `rule-v1` là thuật toán luật. Nếu đề tài đăng ký "Training AI" thì phải bổ sung mô hình thật (xem `docs/16_AI_TRAINING_OPTION.md`) — cần xác nhận với giảng viên.
- **Tranh chấp (`Disputed`)** chỉ tạm dừng xác nhận; chưa có màn hình để Admin xử lý.
- **Admin không duyệt thay claim** và không xem `PrivateProof` (chọn thận trọng theo mặc định Q6).
- **Chưa có:** HTTPS bắt buộc, khoá tài khoản sau nhiều lần đăng nhập sai, thông báo email, xoá mềm bài đăng bởi Admin, unit test tự động.
- Thời gian lưu theo **giờ máy chủ** (`DateTime.Now`).
- **Framework:** nhớ xác nhận với giảng viên là học phần dùng MVC 5 + EF6 Database First (câu hỏi Q2 trong `14_DECISIONS_AND_OPEN_ITEMS.md`).

## 11. Bài tập mở rộng (rất hợp để thực hành sau khi chạy được)

1. Thêm trang Admin xử lý `Disputed`.
2. Thêm nút "Xoá mềm" bài đăng cho Admin (`IsDeleted = true`).
3. Viết unit test cho `MatchService.Score` (hàm thuần, không cần DB) với 8 test case ở `docs/07`.
4. Thêm khoá tạm thời sau 5 lần đăng nhập sai.
5. Thêm bảng `PostImages` và upload ảnh có kiểm tra MIME/kích thước (P1).
