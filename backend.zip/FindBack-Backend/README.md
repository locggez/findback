# HUFLIT FindBack — Backend v0.1 (ASP.NET MVC 5 + EF6 Database First + SQL Server)

Bắt đầu tại **docs/HUONG_DAN_BACKEND.md**.

- `database/`   — 01 schema, 02 seed tham chiếu, 03 dữ liệu demo (tuỳ chọn), 04 nâng Admin
- `FindBack.Web/` — mã nguồn chép vào project MVC 5 (Controllers, Services, ViewModels, Views, CSS/JS, Global.asax.cs)
- `docs/`       — hướng dẫn cho người mới

Frontend gốc: HUFLIT-FindBack-Frontend-v0_4.zip (17 template Razor đã được chuyển thành `.cshtml` và vá nhẹ để khớp backend).
