/* =====================================================================
   HUFLIT FindBack - 01_schema.sql
   Tao database FindBackDb + 9 bang P0 (SQL Server 2016+ / LocalDB).
   CANH BAO: script XOA va tao lai toan bo bang -> mat du lieu cu.
   Chay trong SSMS hoac Visual Studio (SQL Server Object Explorer).
   ===================================================================== */
IF DB_ID(N'FindBackDb') IS NULL
    CREATE DATABASE FindBackDb;
GO
USE FindBackDb;
GO
SET QUOTED_IDENTIFIER ON;   -- bat buoc cho filtered index o duoi
GO

-- Xoa bang theo thu tu nguoc (bang con truoc, bang cha sau)
DROP TABLE IF EXISTS Handovers;
DROP TABLE IF EXISTS Claims;
DROP TABLE IF EXISTS MatchSuggestions;
DROP TABLE IF EXISTS Posts;
DROP TABLE IF EXISTS Locations;
DROP TABLE IF EXISTS Campuses;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Roles;
GO

CREATE TABLE Roles (
    RoleId INT IDENTITY(1,1) CONSTRAINT PK_Roles PRIMARY KEY,
    Name   NVARCHAR(30) NOT NULL CONSTRAINT UQ_Roles_Name UNIQUE
);

CREATE TABLE Users (
    UserId       INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
    RoleId       INT NOT NULL CONSTRAINT FK_Users_Roles REFERENCES Roles(RoleId),
    DisplayName  NVARCHAR(60)  NOT NULL,
    Email        NVARCHAR(256) NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
    PasswordHash NVARCHAR(200) NOT NULL,          -- KHONG BAO GIO luu mat khau that
    IsActive     BIT NOT NULL CONSTRAINT DF_Users_IsActive DEFAULT 1,
    CreatedAt    DATETIME2 NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSDATETIME()
);

CREATE TABLE Campuses (
    CampusId INT IDENTITY(1,1) CONSTRAINT PK_Campuses PRIMARY KEY,
    Name     NVARCHAR(100) NOT NULL CONSTRAINT UQ_Campuses_Name UNIQUE,
    IsActive BIT NOT NULL CONSTRAINT DF_Campuses_IsActive DEFAULT 1
);

CREATE TABLE Locations (
    LocationId INT IDENTITY(1,1) CONSTRAINT PK_Locations PRIMARY KEY,
    CampusId   INT NOT NULL CONSTRAINT FK_Locations_Campuses REFERENCES Campuses(CampusId),
    Name       NVARCHAR(100) NOT NULL,
    IsActive   BIT NOT NULL CONSTRAINT DF_Locations_IsActive DEFAULT 1,
    CONSTRAINT UQ_Locations_Campus_Name UNIQUE (CampusId, Name)
);

CREATE TABLE Categories (
    CategoryId INT IDENTITY(1,1) CONSTRAINT PK_Categories PRIMARY KEY,
    Name       NVARCHAR(60) NOT NULL CONSTRAINT UQ_Categories_Name UNIQUE,
    IsActive   BIT NOT NULL CONSTRAINT DF_Categories_IsActive DEFAULT 1
);

CREATE TABLE Posts (
    PostId            INT IDENTITY(1,1) CONSTRAINT PK_Posts PRIMARY KEY,
    AuthorUserId      INT NOT NULL CONSTRAINT FK_Posts_Users REFERENCES Users(UserId),
    CategoryId        INT NOT NULL CONSTRAINT FK_Posts_Categories REFERENCES Categories(CategoryId),
    LocationId        INT NOT NULL CONSTRAINT FK_Posts_Locations REFERENCES Locations(LocationId),
    PostType          NVARCHAR(10)   NOT NULL CONSTRAINT CK_Posts_PostType CHECK (PostType IN (N'Lost', N'Found')),
    Title             NVARCHAR(100)  NOT NULL,
    PublicDescription NVARCHAR(1000) NOT NULL,
    Color             NVARCHAR(40)   NULL,
    HappenedAt        DATETIME2 NOT NULL,
    CreatedAt         DATETIME2 NOT NULL CONSTRAINT DF_Posts_CreatedAt DEFAULT SYSDATETIME(),
    Status            NVARCHAR(15) NOT NULL CONSTRAINT DF_Posts_Status DEFAULT N'Open'
                      CONSTRAINT CK_Posts_Status CHECK (Status IN (N'Open', N'Resolved', N'Cancelled')),
    IsDeleted         BIT NOT NULL CONSTRAINT DF_Posts_IsDeleted DEFAULT 0
);
CREATE INDEX IX_Posts_Search ON Posts (PostType, Status, CategoryId, LocationId, HappenedAt);
CREATE INDEX IX_Posts_Author ON Posts (AuthorUserId);

CREATE TABLE MatchSuggestions (
    MatchId          INT IDENTITY(1,1) CONSTRAINT PK_MatchSuggestions PRIMARY KEY,
    LostPostId       INT NOT NULL CONSTRAINT FK_Match_LostPost  REFERENCES Posts(PostId),
    FoundPostId      INT NOT NULL CONSTRAINT FK_Match_FoundPost REFERENCES Posts(PostId),
    Score            INT NOT NULL CONSTRAINT CK_Match_Score CHECK (Score BETWEEN 0 AND 100),
    AlgorithmVersion NVARCHAR(20) NOT NULL,
    CreatedAt        DATETIME2 NOT NULL CONSTRAINT DF_Match_CreatedAt DEFAULT SYSDATETIME(),
    CONSTRAINT CK_Match_DifferentPosts CHECK (LostPostId <> FoundPostId),
    CONSTRAINT UQ_Match_Pair UNIQUE (LostPostId, FoundPostId, AlgorithmVersion)
);
CREATE INDEX IX_Match_Lost_Score ON MatchSuggestions (LostPostId, Score);

CREATE TABLE Claims (
    ClaimId           INT IDENTITY(1,1) CONSTRAINT PK_Claims PRIMARY KEY,
    FoundPostId       INT NOT NULL CONSTRAINT FK_Claims_FoundPost REFERENCES Posts(PostId),
    ClaimantUserId    INT NOT NULL CONSTRAINT FK_Claims_Claimant REFERENCES Users(UserId),
    RelatedLostPostId INT NULL CONSTRAINT FK_Claims_LostPost REFERENCES Posts(PostId),
    PrivateProof      NVARCHAR(600) NOT NULL,   -- CHI claimant + chu tin Found duoc doc
    Status            NVARCHAR(15) NOT NULL CONSTRAINT DF_Claims_Status DEFAULT N'Pending'
                      CONSTRAINT CK_Claims_Status CHECK (Status IN (N'Pending', N'Approved', N'Rejected', N'Withdrawn')),
    CreatedAt         DATETIME2 NOT NULL CONSTRAINT DF_Claims_CreatedAt DEFAULT SYSDATETIME(),
    ReviewedAt        DATETIME2 NULL,
    ReviewedByUserId  INT NULL CONSTRAINT FK_Claims_Reviewer REFERENCES Users(UserId)
);
CREATE INDEX IX_Claims_Found_Status ON Claims (FoundPostId, Status);
CREATE INDEX IX_Claims_Claimant ON Claims (ClaimantUserId);
-- Chong 2 claim cung duoc Approved cho 1 tin Found (chong race condition o tang DB)
CREATE UNIQUE INDEX UX_Claims_OneApprovedPerFound ON Claims (FoundPostId) WHERE Status = N'Approved';

CREATE TABLE Handovers (
    HandoverId          INT IDENTITY(1,1) CONSTRAINT PK_Handovers PRIMARY KEY,
    ClaimId             INT NOT NULL CONSTRAINT FK_Handovers_Claims REFERENCES Claims(ClaimId)
                        CONSTRAINT UQ_Handovers_Claim UNIQUE,
    Status              NVARCHAR(15) NOT NULL CONSTRAINT DF_Handovers_Status DEFAULT N'Pending'
                        CONSTRAINT CK_Handovers_Status CHECK (Status IN (N'Pending', N'Completed', N'Disputed')),
    CreatedAt           DATETIME2 NOT NULL CONSTRAINT DF_Handovers_CreatedAt DEFAULT SYSDATETIME(),
    FinderConfirmedAt   DATETIME2 NULL,
    ClaimantConfirmedAt DATETIME2 NULL,
    CompletedAt         DATETIME2 NULL,
    -- Completed chi hop le khi CA HAI ben da xac nhan
    CONSTRAINT CK_Handovers_Completed CHECK (
        (Status <> N'Completed')
        OR (FinderConfirmedAt IS NOT NULL AND ClaimantConfirmedAt IS NOT NULL AND CompletedAt IS NOT NULL)),
    CONSTRAINT CK_Handovers_CompletedAt CHECK (
        CompletedAt IS NULL OR (FinderConfirmedAt IS NOT NULL AND ClaimantConfirmedAt IS NOT NULL))
);
GO
