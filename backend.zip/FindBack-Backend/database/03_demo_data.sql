/* 03_demo_data.sql - DU LIEU DEMO (TUY CHON, chi dung may local).
   Tao 3 tai khoan demo + 6 tin mau. Mat khau demo: Demo@12345  (KHONG dung khi deploy that!)
   Chay SAU 02_seed_reference.sql. */
USE FindBackDb;
GO
DECLARE @Hash NVARCHAR(200) = N'v1.100000.Q10o9CeXM28zsZNSb8ncXQ==.oyDgzdp2ZkOlFM6qsI8/XuAW/YKlxLzcu7wecS9iFq4=';
DECLARE @Student INT = (SELECT RoleId FROM Roles WHERE Name = N'Student');
DECLARE @Admin   INT = (SELECT RoleId FROM Roles WHERE Name = N'Admin');

INSERT INTO Users (RoleId, DisplayName, Email, PasswordHash) VALUES
 (@Admin,   N'Admin Demo',   N'admin.demo@findback.local', @Hash),
 (@Student, N'Sinh viên A',  N'student.a@findback.local',  @Hash),
 (@Student, N'Sinh viên B',  N'student.b@findback.local',  @Hash);

DECLARE @A INT = (SELECT UserId FROM Users WHERE Email = N'student.a@findback.local');
DECLARE @B INT = (SELECT UserId FROM Users WHERE Email = N'student.b@findback.local');

DECLARE @Loc TABLE (Campus NVARCHAR(100), Name NVARCHAR(100), Id INT);
INSERT INTO @Loc SELECT c.Name, l.Name, l.LocationId FROM Locations l JOIN Campuses c ON c.CampusId = l.CampusId;

INSERT INTO Posts (AuthorUserId, CategoryId, LocationId, PostType, Title, PublicDescription, Color, HappenedAt) VALUES
 (@A, (SELECT CategoryId FROM Categories WHERE Name = N'Tai nghe'),
      (SELECT Id FROM @Loc WHERE Campus = N'Sư Vạn Hạnh' AND Name = N'Thư viện'), N'Lost',
      N'Mất tai nghe Bluetooth màu trắng',
      N'Mình để quên tai nghe không dây màu trắng gần khu tự học. Nhờ mọi người hỗ trợ tìm giúp.',
      N'Trắng', DATEADD(HOUR, -19, SYSDATETIME())),
 (@B, (SELECT CategoryId FROM Categories WHERE Name = N'Tai nghe'),
      (SELECT Id FROM @Loc WHERE Campus = N'Sư Vạn Hạnh' AND Name = N'Thư viện'), N'Found',
      N'Nhặt được tai nghe không dây màu trắng',
      N'Mình nhặt được một tai nghe không dây ở thư viện, hiện đang giữ an toàn để chờ chủ đến xác minh.',
      N'Trắng', DATEADD(HOUR, -18, SYSDATETIME())),
 (@B, (SELECT CategoryId FROM Categories WHERE Name = N'Ví / bóp'),
      (SELECT Id FROM @Loc WHERE Campus = N'Ba Gia' AND Name = N'Hành lang'), N'Lost',
      N'Tìm ví màu nâu nhỏ',
      N'Mình làm rơi ví màu nâu gần hành lang. Nếu bạn nào có nhặt được, mong được liên hệ qua hệ thống.',
      N'Nâu', DATEADD(HOUR, -30, SYSDATETIME())),
 (@A, (SELECT CategoryId FROM Categories WHERE Name = N'Thẻ / giấy tờ'),
      (SELECT Id FROM @Loc WHERE Campus = N'Trường Sơn' AND Name = N'Sảnh chính'), N'Found',
      N'Nhặt được thẻ nhựa',
      N'Có một thẻ nhựa được nhặt tại sảnh. Mình sẽ xác minh chủ sở hữu trước khi trao trả.',
      N'Xanh', DATEADD(HOUR, -9, SYSDATETIME())),
 (@B, (SELECT CategoryId FROM Categories WHERE Name = N'Sạc / phụ kiện'),
      (SELECT Id FROM @Loc WHERE Campus = N'Hóc Môn' AND Name = N'Phòng học'), N'Found',
      N'Có bạn nào mất dây sạc USB-C?',
      N'Nhặt được một dây sạc gần phòng học. Chủ sở hữu vui lòng mô tả chi tiết để nhận lại.',
      N'Đen', DATEADD(HOUR, -13, SYSDATETIME())),
 (@A, (SELECT CategoryId FROM Categories WHERE Name = N'Sạc / phụ kiện'),
      (SELECT Id FROM @Loc WHERE Campus = N'Hóc Môn' AND Name = N'Phòng học'), N'Lost',
      N'Tìm dây sạc màu đen',
      N'Mình làm thất lạc dây sạc màu đen trong phòng học vào buổi chiều. Nhờ mọi người hỗ trợ.',
      N'Đen', DATEADD(HOUR, -14, SYSDATETIME()));
GO
