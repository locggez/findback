/* 04_make_admin.sql - nang 1 tai khoan da DANG KY tren website len Admin.
   Sua email ben duoi roi chay. */
USE FindBackDb;
GO
DECLARE @Email NVARCHAR(256) = N'ban@example.com';   -- <-- SUA EMAIL O DAY
UPDATE Users SET RoleId = (SELECT RoleId FROM Roles WHERE Name = N'Admin')
WHERE Email = LOWER(@Email);
SELECT UserId, DisplayName, Email, RoleId FROM Users WHERE Email = LOWER(@Email);
GO
