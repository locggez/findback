/* 02_seed_reference.sql - du lieu tham chieu BAT BUOC (vai tro, co so, khu vuc, danh muc).
   Chay SAU 01_schema.sql. */
USE FindBackDb;
GO
INSERT INTO Roles (Name) VALUES (N'Student'), (N'Admin');

INSERT INTO Campuses (Name) VALUES (N'Sư Vạn Hạnh'), (N'Trường Sơn'), (N'Ba Gia'), (N'Hóc Môn');

INSERT INTO Locations (CampusId, Name)
SELECT c.CampusId, v.Name
FROM (VALUES
    (N'Sư Vạn Hạnh', N'Sảnh chính'), (N'Sư Vạn Hạnh', N'Thư viện'), (N'Sư Vạn Hạnh', N'Phòng học'),
    (N'Sư Vạn Hạnh', N'Hành lang'),  (N'Sư Vạn Hạnh', N'Căn tin'),
    (N'Trường Sơn', N'Sảnh chính'), (N'Trường Sơn', N'Phòng học'), (N'Trường Sơn', N'Hành lang'), (N'Trường Sơn', N'Khu tự học'),
    (N'Ba Gia', N'Sảnh chính'), (N'Ba Gia', N'Phòng học'), (N'Ba Gia', N'Hành lang'), (N'Ba Gia', N'Khu tự học'),
    (N'Hóc Môn', N'Sảnh chính'), (N'Hóc Môn', N'Phòng học'), (N'Hóc Môn', N'Sân trường'), (N'Hóc Môn', N'Khu tự học')
) AS v(CampusName, Name)
JOIN Campuses c ON c.Name = v.CampusName;

INSERT INTO Categories (Name) VALUES
 (N'Tai nghe'), (N'Ví / bóp'), (N'Thẻ / giấy tờ'), (N'Điện thoại'), (N'Chìa khóa'),
 (N'Sạc / phụ kiện'), (N'Sách / tài liệu'), (N'Balo / túi xách'), (N'Khác');
GO
